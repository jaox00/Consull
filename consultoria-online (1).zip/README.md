# 🏢 Plataforma de Consultoria Online

Uma plataforma completa para conectar consultores e clientes, com sistema de agendamento, chat em tempo real e dashboards personalizados.

## 🚀 Tecnologias Utilizadas

### Frontend
- **React 18** - Interface de usuário moderna
- **Next.js 14** - Framework React com App Router
- **Tailwind CSS** - Estilização responsiva e profissional
- **Socket.IO Client** - Chat em tempo real
- **Recharts** - Gráficos e visualizações

### Backend
- **Node.js** - Runtime JavaScript
- **Express.js** - Framework web
- **Socket.IO** - Comunicação em tempo real
- **MongoDB** - Banco de dados NoSQL
- **Mongoose** - ODM para MongoDB
- **JWT** - Autenticação segura
- **bcryptjs** - Criptografia de senhas

### DevOps
- **Docker** - Containerização
- **Docker Compose** - Orquestração de serviços
- **MongoDB Express** - Interface web para o banco

## 📁 Estrutura do Projeto

\`\`\`
consultoria-online/
├── app/                    # Frontend Next.js
│   ├── (auth)/            # Páginas de autenticação
│   ├── dashboard/         # Dashboards
│   ├── globals.css        # Estilos globais
│   └── layout.tsx         # Layout principal
├── backend/               # Backend Node.js
│   ├── models/           # Modelos do MongoDB
│   ├── routes/           # Rotas da API
│   ├── middleware/       # Middlewares
│   ├── utils/            # Utilitários
│   └── server.js         # Servidor principal
├── components/           # Componentes React
├── lib/                 # Utilitários do frontend
├── docker-compose.yml   # Configuração Docker
└── README.md           # Este arquivo
\`\`\`

## 🛠️ Instalação e Execução

### Pré-requisitos
- Docker e Docker Compose instalados
- Node.js 18+ (para desenvolvimento local)

### Usando Docker (Recomendado)

1. **Clone o repositório**
\`\`\`bash
git clone <url-do-repositorio>
cd consultoria-online
\`\`\`

2. **Execute com Docker Compose**
\`\`\`bash
docker-compose up --build
\`\`\`

3. **Acesse a aplicação**
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000
- MongoDB Express: http://localhost:8081 (admin/admin123)

### Desenvolvimento Local

1. **Backend**
\`\`\`bash
cd backend
npm install
npm run dev
\`\`\`

2. **Frontend**
\`\`\`bash
npm install
npm run dev
\`\`\`

## 🔧 Configuração

### Variáveis de Ambiente

**Backend (.env)**
\`\`\`env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/consultoria
JWT_SECRET=sua_chave_secreta_jwt_aqui
CORS_ORIGIN=http://localhost:3000
\`\`\`

**Frontend**
\`\`\`env
NEXT_PUBLIC_API_URL=http://localhost:5000
NEXT_PUBLIC_SOCKET_URL=http://localhost:5000
\`\`\`

## 📊 Funcionalidades

### 🔐 Autenticação
- Cadastro e login para consultores e clientes
- Autenticação JWT segura
- Proteção de rotas

### 👨‍💼 Dashboard do Consultor
- Gerenciamento de clientes
- Agenda de consultas
- Histórico de atendimentos
- Métricas e relatórios

### 👤 Dashboard do Cliente
- Agendamento de consultas
- Histórico de sessões
- Perfil pessoal
- Avaliações

### 💬 Chat em Tempo Real
- Comunicação instantânea
- Indicador de digitação
- Histórico de mensagens
- Notificações

### 📱 Design Responsivo
- Interface adaptável para mobile e desktop
- Tema claro e escuro
- Componentes acessíveis

## 🧪 Testes

\`\`\`bash
# Backend
cd backend
npm test

# Frontend
npm test
\`\`\`

## 🚀 Deploy

### Produção com Docker
\`\`\`bash
docker-compose -f docker-compose.prod.yml up --build
\`\`\`

### Deploy na Vercel (Frontend)
\`\`\`bash
vercel --prod
\`\`\`

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📝 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 📞 Suporte

Para suporte, envie um email para suporte@consultoria.com ou abra uma issue no GitHub.

---

**Desenvolvido com ❤️ para conectar consultores e clientes de forma eficiente e profissional.**
