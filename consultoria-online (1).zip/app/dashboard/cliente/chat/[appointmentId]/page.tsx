/**
 * Página de chat do cliente
 * Interface de chat para comunicação com consultores
 */
"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { appointmentsApi } from "@/lib/api"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { Header } from "@/components/layout/header"
import { ChatWindow } from "@/components/chat/chat-window"
import { Card, CardContent } from "@/components/ui/card"
import { toast } from "@/hooks/use-toast"
import { ArrowLeft, Calendar, Clock, User, Star } from "lucide-react"
import Link from "next/link"

export default function ClienteChat() {
  const params = useParams()
  const appointmentId = params.appointmentId as string
  const [appointment, setAppointment] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadAppointment()
  }, [appointmentId])

  const loadAppointment = async () => {
    try {
      setLoading(true)
      const response = await appointmentsApi.getById(appointmentId)
      setAppointment(response.data?.appointment)
    } catch (error) {
      console.error("Erro ao carregar agendamento:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar os dados do agendamento",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <ProtectedRoute requiredUserType="client">
        <div className="min-h-screen bg-background">
          <Header />
          <main className="container py-8">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-muted-foreground">Carregando chat...</p>
            </div>
          </main>
        </div>
      </ProtectedRoute>
    )
  }

  if (!appointment) {
    return (
      <ProtectedRoute requiredUserType="client">
        <div className="min-h-screen bg-background">
          <Header />
          <main className="container py-8">
            <div className="text-center">
              <h2 className="text-xl font-semibold mb-2">Agendamento não encontrado</h2>
              <p className="text-muted-foreground mb-4">O agendamento solicitado não existe ou foi removido.</p>
              <Link
                href="/dashboard/cliente"
                className="inline-flex items-center space-x-2 text-primary hover:underline"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Voltar ao Dashboard</span>
              </Link>
            </div>
          </main>
        </div>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute requiredUserType="client">
      <div className="min-h-screen bg-background">
        <Header />

        <main className="container py-8">
          <div className="max-w-4xl mx-auto">
            {/* Cabeçalho */}
            <div className="mb-6">
              <Link
                href="/dashboard/cliente"
                className="inline-flex items-center space-x-2 text-muted-foreground hover:text-foreground mb-4"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Voltar ao Dashboard</span>
              </Link>

              <h1 className="text-3xl font-bold mb-2">Chat - {appointment.title}</h1>
              <p className="text-muted-foreground">Conversa com {appointment.consultant.name}</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Informações do consultor */}
              <div className="lg:col-span-1">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold mb-4">Seu Consultor</h3>

                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">{appointment.consultant.name}</p>
                          <p className="text-xs text-muted-foreground">{appointment.consultant.email}</p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">
                            {new Date(appointment.date).toLocaleDateString("pt-BR")}
                          </p>
                          <p className="text-xs text-muted-foreground">Data da consulta</p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">{appointment.time}</p>
                          <p className="text-xs text-muted-foreground">Horário</p>
                        </div>
                      </div>

                      {appointment.consultant.rating && (
                        <div className="flex items-center space-x-2">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <div>
                            <p className="text-sm font-medium">{appointment.consultant.rating.toFixed(1)}</p>
                            <p className="text-xs text-muted-foreground">Avaliação média</p>
                          </div>
                        </div>
                      )}
                    </div>

                    {appointment.consultant.bio && (
                      <div className="mt-4 pt-4 border-t">
                        <h4 className="text-sm font-medium mb-2">Sobre o Consultor</h4>
                        <p className="text-sm text-muted-foreground">{appointment.consultant.bio}</p>
                      </div>
                    )}

                    {appointment.notes && (
                      <div className="mt-4 pt-4 border-t">
                        <h4 className="text-sm font-medium mb-2">Suas Observações</h4>
                        <p className="text-sm text-muted-foreground">{appointment.notes}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Chat */}
              <div className="lg:col-span-2">
                <ChatWindow
                  appointmentId={appointmentId}
                  otherUser={{
                    _id: appointment.consultant._id,
                    name: appointment.consultant.name,
                    userType: "consultant",
                  }}
                />
              </div>
            </div>
          </div>
        </main>
      </div>
    </ProtectedRoute>
  )
}
