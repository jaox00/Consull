/**
 * Página para agendar consultas
 * Busca de consultores e formulário de agendamento
 */
"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { usersApi, appointmentsApi } from "@/lib/api"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { toast } from "@/hooks/use-toast"
import { Search, Star, Clock, CalendarIcon, Filter, Loader2 } from "lucide-react"
import { format, addDays, setHours, setMinutes } from "date-fns"
import { ptBR } from "date-fns/locale"

interface Consultant {
  _id: string
  name: string
  email: string
  avatar?: string
  consultantInfo: {
    specialties: string[]
    experience: number
    hourlyRate: number
    rating: {
      average: number
      count: number
    }
  }
}

export default function AgendarConsulta() {
  const [consultants, setConsultants] = useState<Consultant[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [specialtyFilter, setSpecialtyFilter] = useState("")
  const [selectedConsultant, setSelectedConsultant] = useState<Consultant | null>(null)
  const [showBookingDialog, setShowBookingDialog] = useState(false)
  const [bookingLoading, setBookingLoading] = useState(false)

  // Dados do agendamento
  const [bookingData, setBookingData] = useState({
    title: "",
    description: "",
    scheduledDate: undefined as Date | undefined,
    duration: 60,
    selectedTime: "",
  })

  const router = useRouter()

  useEffect(() => {
    loadConsultants()
  }, [])

  const loadConsultants = async () => {
    try {
      setLoading(true)
      const response = await usersApi.getConsultants({ limit: 50 })
      setConsultants(response.data?.consultants || [])
    } catch (error) {
      console.error("Erro ao carregar consultores:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar os consultores",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const filteredConsultants = consultants.filter((consultant) => {
    const matchesSearch =
      consultant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      consultant.consultantInfo.specialties.some((specialty) =>
        specialty.toLowerCase().includes(searchTerm.toLowerCase()),
      )

    const matchesSpecialty =
      !specialtyFilter ||
      consultant.consultantInfo.specialties.some((specialty) =>
        specialty.toLowerCase().includes(specialtyFilter.toLowerCase()),
      )

    return matchesSearch && matchesSpecialty
  })

  const handleBookConsultant = (consultant: Consultant) => {
    setSelectedConsultant(consultant)
    setBookingData({
      title: "",
      description: "",
      scheduledDate: undefined,
      duration: 60,
      selectedTime: "",
    })
    setShowBookingDialog(true)
  }

  const handleBookingSubmit = async () => {
    if (!selectedConsultant || !bookingData.scheduledDate || !bookingData.selectedTime || !bookingData.title) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive",
      })
      return
    }

    try {
      setBookingLoading(true)

      // Combina data e horário
      const [hours, minutes] = bookingData.selectedTime.split(":").map(Number)
      const scheduledDateTime = setMinutes(setHours(bookingData.scheduledDate, hours), minutes)

      const appointmentData = {
        consultant: selectedConsultant._id,
        title: bookingData.title,
        description: bookingData.description,
        scheduledDate: scheduledDateTime.toISOString(),
        duration: bookingData.duration,
      }

      await appointmentsApi.create(appointmentData)

      toast({
        title: "Consulta agendada!",
        description: "Sua consulta foi agendada com sucesso. O consultor será notificado.",
      })

      setShowBookingDialog(false)
      router.push("/agendamentos")
    } catch (error: any) {
      console.error("Erro ao agendar consulta:", error)
      toast({
        title: "Erro ao agendar",
        description: error.message || "Não foi possível agendar a consulta",
        variant: "destructive",
      })
    } finally {
      setBookingLoading(false)
    }
  }

  // Gera horários disponíveis (9h às 18h, de hora em hora)
  const availableTimes = []
  for (let hour = 9; hour <= 18; hour++) {
    availableTimes.push(`${hour.toString().padStart(2, "0")}:00`)
    if (hour < 18) {
      availableTimes.push(`${hour.toString().padStart(2, "0")}:30`)
    }
  }

  // Especialidades únicas para filtro
  const allSpecialties = Array.from(new Set(consultants.flatMap((consultant) => consultant.consultantInfo.specialties)))

  return (
    <ProtectedRoute requiredUserType="client">
      <div className="min-h-screen bg-background">
        <Header />

        <main className="container py-8">
          {/* Cabeçalho */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Agendar Consulta</h1>
            <p className="text-muted-foreground">Encontre o especialista ideal para suas necessidades</p>
          </div>

          {/* Filtros */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                <div className="flex items-center space-x-4 flex-1">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Buscar por nome ou especialidade..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Select value={specialtyFilter} onValueChange={setSpecialtyFilter}>
                    <SelectTrigger className="w-48">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="Especialidade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Todas</SelectItem>
                      {allSpecialties.map((specialty) => (
                        <SelectItem key={specialty} value={specialty}>
                          {specialty}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Lista de consultores */}
          <div className="space-y-4">
            {loading ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                  <p className="text-muted-foreground">Carregando consultores...</p>
                </CardContent>
              </Card>
            ) : filteredConsultants.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="text-muted-foreground">
                    {searchTerm || specialtyFilter ? "Nenhum consultor encontrado" : "Nenhum consultor disponível"}
                  </p>
                </CardContent>
              </Card>
            ) : (
              filteredConsultants.map((consultant) => (
                <Card key={consultant._id}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <Avatar className="h-16 w-16">
                          <AvatarImage src={consultant.avatar || "/placeholder.svg"} />
                          <AvatarFallback className="text-lg">
                            {consultant.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold text-xl">{consultant.name}</h3>
                          <div className="flex items-center space-x-2 mt-1">
                            <div className="flex items-center space-x-1">
                              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                              <span className="font-medium">{consultant.consultantInfo.rating.average.toFixed(1)}</span>
                              <span className="text-sm text-muted-foreground">
                                ({consultant.consultantInfo.rating.count} avaliações)
                              </span>
                            </div>
                            <Badge variant="secondary">{consultant.consultantInfo.experience} anos</Badge>
                          </div>
                          <div className="flex flex-wrap gap-2 mt-2">
                            {consultant.consultantInfo.specialties.slice(0, 3).map((specialty) => (
                              <Badge key={specialty} variant="outline">
                                {specialty}
                              </Badge>
                            ))}
                            {consultant.consultantInfo.specialties.length > 3 && (
                              <Badge variant="outline">+{consultant.consultantInfo.specialties.length - 3}</Badge>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        <p className="text-2xl font-bold text-primary">
                          {new Intl.NumberFormat("pt-BR", {
                            style: "currency",
                            currency: "BRL",
                          }).format(consultant.consultantInfo.hourlyRate)}
                          <span className="text-sm font-normal">/hora</span>
                        </p>
                        <Button className="mt-4" onClick={() => handleBookConsultant(consultant)}>
                          Agendar Consulta
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>

          {/* Dialog de agendamento */}
          <Dialog open={showBookingDialog} onOpenChange={setShowBookingDialog}>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Agendar Consulta</DialogTitle>
                <DialogDescription>{selectedConsultant && `Consulta com ${selectedConsultant.name}`}</DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Título da consulta *</Label>
                  <Input
                    id="title"
                    placeholder="Ex: Consultoria em Marketing Digital"
                    value={bookingData.title}
                    onChange={(e) => setBookingData({ ...bookingData, title: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Descrição (opcional)</Label>
                  <Textarea
                    id="description"
                    placeholder="Descreva brevemente o que você gostaria de discutir..."
                    value={bookingData.description}
                    onChange={(e) => setBookingData({ ...bookingData, description: e.target.value })}
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Data *</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal bg-transparent">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {bookingData.scheduledDate
                            ? format(bookingData.scheduledDate, "dd/MM/yyyy", { locale: ptBR })
                            : "Selecionar"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={bookingData.scheduledDate}
                          onSelect={(date) => setBookingData({ ...bookingData, scheduledDate: date })}
                          disabled={(date) => date < addDays(new Date(), 1)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <Label>Horário *</Label>
                    <Select
                      value={bookingData.selectedTime}
                      onValueChange={(time) => setBookingData({ ...bookingData, selectedTime: time })}
                    >
                      <SelectTrigger>
                        <Clock className="mr-2 h-4 w-4" />
                        <SelectValue placeholder="Horário" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableTimes.map((time) => (
                          <SelectItem key={time} value={time}>
                            {time}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Duração</Label>
                  <Select
                    value={bookingData.duration.toString()}
                    onValueChange={(duration) =>
                      setBookingData({ ...bookingData, duration: Number.parseInt(duration) })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">30 minutos</SelectItem>
                      <SelectItem value="60">1 hora</SelectItem>
                      <SelectItem value="90">1h 30min</SelectItem>
                      <SelectItem value="120">2 horas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {selectedConsultant && (
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="flex justify-between items-center">
                      <span>Valor estimado:</span>
                      <span className="font-bold text-primary">
                        {new Intl.NumberFormat("pt-BR", {
                          style: "currency",
                          currency: "BRL",
                        }).format((selectedConsultant.consultantInfo.hourlyRate * bookingData.duration) / 60)}
                      </span>
                    </div>
                  </div>
                )}

                <div className="flex space-x-2 pt-4">
                  <Button variant="outline" onClick={() => setShowBookingDialog(false)} className="flex-1">
                    Cancelar
                  </Button>
                  <Button onClick={handleBookingSubmit} disabled={bookingLoading} className="flex-1">
                    {bookingLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Agendando...
                      </>
                    ) : (
                      "Confirmar Agendamento"
                    )}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </ProtectedRoute>
  )
}
