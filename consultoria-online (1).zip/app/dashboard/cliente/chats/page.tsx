/**
 * Página de chats ativos do cliente
 * Lista de conversas em andamento
 */
"use client"

import { ProtectedRoute } from "@/components/auth/protected-route"
import { Header } from "@/components/layout/header"
import { ChatList } from "@/components/chat/chat-list"

export default function ClienteChats() {
  return (
    <ProtectedRoute requiredUserType="client">
      <div className="min-h-screen bg-background">
        <Header />

        <main className="container py-8">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold mb-2">Seus Chats</h1>
              <p className="text-muted-foreground">Conversas com seus consultores</p>
            </div>

            <ChatList userType="client" />
          </div>
        </main>
      </div>
    </ProtectedRoute>
  )
}
