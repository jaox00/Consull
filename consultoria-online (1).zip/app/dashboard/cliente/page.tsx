/**
 * Dashboard principal do cliente
 * Visão geral com próximas consultas, consultores favoritos e estatísticas
 */
"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { appointmentsApi, usersApi } from "@/lib/api"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Calendar, Clock, Star, Search, Plus, MessageSquare, ChevronRight, CalendarDays, Users } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface DashboardStats {
  totalAppointments: number
  upcomingAppointments: any[]
  recentAppointments: any[]
  favoriteConsultants: any[]
  totalSpent: number
}

export default function ClienteDashboard() {
  const { user } = useAuth()
  const [stats, setStats] = useState<DashboardStats>({
    totalAppointments: 0,
    upcomingAppointments: [],
    recentAppointments: [],
    favoriteConsultants: [],
    totalSpent: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadDashboardData()
  }, [])

  const loadDashboardData = async () => {
    try {
      // Busca agendamentos do cliente
      const [upcomingResponse, allAppointmentsResponse, consultantsResponse] = await Promise.all([
        appointmentsApi.getAll({
          status: "scheduled,confirmed,in-progress",
          startDate: new Date().toISOString(),
          limit: 5,
        }),
        appointmentsApi.getAll({ limit: 100 }),
        usersApi.getConsultants({ limit: 6 }),
      ])

      const upcomingAppointments = upcomingResponse.data?.appointments || []
      const allAppointments = allAppointmentsResponse.data?.appointments || []
      const consultants = consultantsResponse.data?.consultants || []

      // Calcula estatísticas
      const completedAppointments = allAppointments.filter((apt: any) => apt.status === "completed")
      const totalSpent = completedAppointments.reduce((sum: number, apt: any) => sum + apt.price, 0)

      // Consultores mais consultados (favoritos)
      const consultantCounts = new Map()
      completedAppointments.forEach((apt: any) => {
        const consultantId = apt.consultant._id
        consultantCounts.set(consultantId, (consultantCounts.get(consultantId) || 0) + 1)
      })

      const favoriteConsultants = consultants
        .filter((consultant: any) => consultantCounts.has(consultant._id))
        .sort((a: any, b: any) => (consultantCounts.get(b._id) || 0) - (consultantCounts.get(a._id) || 0))
        .slice(0, 3)

      setStats({
        totalAppointments: allAppointments.length,
        upcomingAppointments,
        recentAppointments: completedAppointments.slice(0, 5),
        favoriteConsultants,
        totalSpent,
      })
    } catch (error) {
      console.error("Erro ao carregar dados do dashboard:", error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      case "confirmed":
        return "bg-green-100 text-green-800"
      case "in-progress":
        return "bg-yellow-100 text-yellow-800"
      case "completed":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "scheduled":
        return "Agendado"
      case "confirmed":
        return "Confirmado"
      case "in-progress":
        return "Em andamento"
      case "completed":
        return "Concluído"
      default:
        return status
    }
  }

  return (
    <ProtectedRoute requiredUserType="client">
      <div className="min-h-screen bg-background">
        <Header />

        <main className="container py-8">
          {/* Cabeçalho */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Meu Dashboard</h1>
            <p className="text-muted-foreground">
              Bem-vindo de volta, {user?.name}! Gerencie suas consultas e encontre especialistas.
            </p>
          </div>

          {/* Cards de métricas */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total de Consultas</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalAppointments}</div>
                <p className="text-xs text-muted-foreground">Consultas realizadas</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Próximas Consultas</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.upcomingAppointments.length}</div>
                <p className="text-xs text-muted-foreground">Agendamentos confirmados</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Investido</CardTitle>
                <Star className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {new Intl.NumberFormat("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  }).format(stats.totalSpent)}
                </div>
                <p className="text-xs text-muted-foreground">Em consultorias</p>
              </CardContent>
            </Card>
          </div>

          {/* Ação rápida - Agendar consulta */}
          <Card className="mb-8 bg-primary text-primary-foreground">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold mb-2">Precisa de uma consultoria?</h3>
                  <p className="opacity-90">Encontre o especialista ideal para suas necessidades</p>
                </div>
                <Button size="lg" variant="secondary" asChild>
                  <Link href="/dashboard/cliente/agendar">
                    <Plus className="mr-2 h-4 w-4" />
                    Agendar Consulta
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Próximas consultas */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Próximas Consultas</CardTitle>
                    <CardDescription>Seus agendamentos confirmados</CardDescription>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <Link href="/agendamentos">
                      Ver todas
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {stats.upcomingAppointments.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <CalendarDays className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Nenhuma consulta agendada</p>
                    <Button variant="outline" className="mt-4 bg-transparent" asChild>
                      <Link href="/dashboard/cliente/agendar">Agendar primeira consulta</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {stats.upcomingAppointments.map((appointment: any) => (
                      <div key={appointment._id} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={appointment.consultant.avatar || "/placeholder.svg"} />
                          <AvatarFallback>
                            {appointment.consultant.name
                              .split(" ")
                              .map((n: string) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{appointment.title}</p>
                          <p className="text-sm text-muted-foreground">com {appointment.consultant.name}</p>
                          <div className="flex items-center space-x-2 mt-1">
                            <Clock className="h-3 w-3 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">
                              {format(new Date(appointment.scheduledDate), "dd/MM 'às' HH:mm", { locale: ptBR })}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getStatusColor(appointment.status)}>
                            {getStatusText(appointment.status)}
                          </Badge>
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/chat?room=${appointment.chatRoomId}`}>
                              <MessageSquare className="h-4 w-4" />
                            </Link>
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Consultores favoritos */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Seus Consultores</CardTitle>
                    <CardDescription>Especialistas que você já consultou</CardDescription>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <Link href="/consultores">
                      Explorar mais
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {stats.favoriteConsultants.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Você ainda não consultou nenhum especialista</p>
                    <Button variant="outline" className="mt-4 bg-transparent" asChild>
                      <Link href="/consultores">Encontrar consultores</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {stats.favoriteConsultants.map((consultant: any) => (
                      <div key={consultant._id} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={consultant.avatar || "/placeholder.svg"} />
                          <AvatarFallback>
                            {consultant.name
                              .split(" ")
                              .map((n: string) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium">{consultant.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {consultant.consultantInfo?.specialties?.slice(0, 2).join(", ")}
                          </p>
                          <div className="flex items-center space-x-1 mt-1">
                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                            <span className="text-xs">
                              {consultant.consultantInfo?.rating?.average?.toFixed(1) || "0.0"}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              ({consultant.consultantInfo?.rating?.count || 0})
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium text-primary">
                            {new Intl.NumberFormat("pt-BR", {
                              style: "currency",
                              currency: "BRL",
                            }).format(consultant.consultantInfo?.hourlyRate || 0)}
                            /h
                          </p>
                          <Button variant="outline" size="sm" className="mt-2 bg-transparent" asChild>
                            <Link href={`/consultores/${consultant._id}`}>Ver perfil</Link>
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Histórico recente */}
          {stats.recentAppointments.length > 0 && (
            <Card className="mt-8">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Consultas Recentes</CardTitle>
                    <CardDescription>Suas últimas consultorias concluídas</CardDescription>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <Link href="/dashboard/cliente/historico">
                      Ver histórico completo
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {stats.recentAppointments.map((appointment: any) => (
                    <div key={appointment._id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={appointment.consultant.avatar || "/placeholder.svg"} />
                          <AvatarFallback>
                            {appointment.consultant.name
                              .split(" ")
                              .map((n: string) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{appointment.title}</p>
                          <p className="text-sm text-muted-foreground">com {appointment.consultant.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {format(new Date(appointment.scheduledDate), "dd/MM/yyyy", { locale: ptBR })}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">
                          {new Intl.NumberFormat("pt-BR", {
                            style: "currency",
                            currency: "BRL",
                          }).format(appointment.price)}
                        </p>
                        {appointment.clientFeedback?.rating ? (
                          <div className="flex items-center space-x-1">
                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                            <span className="text-xs">Avaliado: {appointment.clientFeedback.rating}</span>
                          </div>
                        ) : (
                          <Button variant="outline" size="sm" className="mt-1 bg-transparent" asChild>
                            <Link href={`/agendamentos/${appointment._id}?action=rate`}>Avaliar</Link>
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Ações rápidas */}
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Ações Rápidas</CardTitle>
              <CardDescription>Acesse rapidamente as principais funcionalidades</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button variant="outline" className="h-20 flex-col space-y-2 bg-transparent" asChild>
                  <Link href="/consultores">
                    <Search className="h-6 w-6" />
                    <span>Encontrar Consultores</span>
                  </Link>
                </Button>
                <Button variant="outline" className="h-20 flex-col space-y-2 bg-transparent" asChild>
                  <Link href="/agendamentos">
                    <Calendar className="h-6 w-6" />
                    <span>Meus Agendamentos</span>
                  </Link>
                </Button>
                <Button variant="outline" className="h-20 flex-col space-y-2 bg-transparent" asChild>
                  <Link href="/chat">
                    <MessageSquare className="h-6 w-6" />
                    <span>Conversas</span>
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </ProtectedRoute>
  )
}
