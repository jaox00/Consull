/**
 * Página de histórico de consultas do cliente
 * Lista de consultas passadas com opção de avaliação
 */
"use client"

import { useState, useEffect } from "react"
import { appointmentsApi } from "@/lib/api"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { toast } from "@/hooks/use-toast"
import { Calendar, Star, Search, FileText } from "lucide-react"

export default function ClienteHistorico() {
  const [appointments, setAppointments] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [showRatingDialog, setShowRatingDialog] = useState(false)
  const [selectedAppointment, setSelectedAppointment] = useState<any>(null)
  const [ratingData, setRatingData] = useState({
    rating: 0,
    comment: "",
  })
  const [ratingLoading, setRatingLoading] = useState(false)

  useEffect(() => {
    loadAppointments()
  }, [statusFilter])

  const loadAppointments = async () => {
    try {
      setLoading(true)
      const params: any = { limit: 100 }

      if (statusFilter !== "all") {
        params.status = statusFilter
      }

      const response = await appointmentsApi.getAll(params)
      setAppointments(response.data?.appointments || [])
    } catch (error) {
      console.error("Erro ao carregar histórico:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar o histórico",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const filteredAppointments = appointments.filter(
    (appointment: any) =>
      appointment.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      appointment.consultant.name.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleRateAppointment = (appointment: any) => {
    setSelectedAppointment(appointment)
    setRatingData({
      rating: appointment.clientFeedback?.rating || 0,
      comment: appointment.clientFeedback?.comment || "",
    })
    setShowRatingDialog(true)
  }

  const handleSubmitRating = async () => {
    if (!selectedAppointment || ratingData.rating === 0) {
      toast({
        title: "Erro",
        description: "Selecione uma avaliação de 1 a 5 estrelas",
        variant: "destructive",
      })
      return
    }

    try {
      setRatingLoading(true)
      await appointmentsApi.addFeedback(selectedAppointment._id, ratingData.rating, ratingData.comment)

      toast({
        title: "Avaliação enviada!",
        description: "Obrigado pelo seu feedback",
      })

      setShowRatingDialog(false)
      loadAppointments() // Recarrega para mostrar a avaliação
    } catch (error: any) {
      console.error("Erro ao enviar avaliação:", error)
      toast({
        title: "Erro",
        description: error.message || "Não foi possível enviar a avaliação",
        variant: "destructive",
      })
    } finally {
      setRatingLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      case "confirmed":
        return "bg-green-100 text-green-800"
      case "in-progress":
        return "bg-yellow-100 text-yellow-800"
      case "completed":
        return "bg-gray-100 text-gray-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "scheduled":
        return "Agendado"
      case "confirmed":
        return "Confirmado"
      case "in-progress":
        return "Em andamento"
      case "completed":
        return "Concluído"
      case "cancelled":
        return "Cancelado"
      default:
        return status
    }
  }

  const stats = {
    total: appointments.length,
    completed: appointments.filter((apt: any) => apt.status === "completed").length,
    totalSpent: appointments
      .filter((apt: any) => apt.status === "completed")
      .reduce((sum: number, apt: any) => sum + apt.price, 0),
  }

  return (
    <ProtectedRoute requiredUserType="client">
      <div className="min-h-screen bg-background">
        <Header />

        <main className="container py-8">
          {/* Cabeçalho */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Histórico de Consultas</h1>
            <p className="text-muted-foreground">Suas consultorias passadas e avaliações</p>
          </div>

          {/* Estatísticas */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total de Consultas</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.total}</div>
                <p className="text-xs text-muted-foreground">Consultas realizadas</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Consultas Concluídas</CardTitle>
                <Star className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.completed}</div>
                <p className="text-xs text-muted-foreground">Finalizadas com sucesso</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Investido</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {new Intl.NumberFormat("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  }).format(stats.totalSpent)}
                </div>
                <p className="text-xs text-muted-foreground">Em consultorias</p>
              </CardContent>
            </Card>
          </div>

          {/* Filtros */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar consultas..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-3 py-2 border border-input bg-background rounded-md text-sm"
                >
                  <option value="all">Todos os status</option>
                  <option value="completed">Concluídas</option>
                  <option value="cancelled">Canceladas</option>
                  <option value="scheduled">Agendadas</option>
                </select>
              </div>
            </CardHeader>
          </Card>

          {/* Lista de consultas */}
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-muted-foreground">Carregando histórico...</p>
            </div>
          ) : filteredAppointments.length === 0 ? (
            <Card>
              <CardContent className="text-center py-8">
                <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhuma consulta encontrada</h3>
                <p className="text-muted-foreground">
                  {searchTerm ? "Tente ajustar os filtros de busca" : "Você ainda não realizou consultas"}
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredAppointments.map((appointment: any) => (
                <Card key={appointment._id}>
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold">{appointment.title}</h3>
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(appointment.status)}`}
                          >
                            {getStatusText(appointment.status)}
                          </span>
                        </div>

                        <p className="text-sm text-muted-foreground mb-2">Consultor: {appointment.consultant.name}</p>

                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span>📅 {new Date(appointment.date).toLocaleDateString("pt-BR")}</span>
                          <span>🕒 {appointment.time}</span>
                          <span>
                            💰{" "}
                            {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                              appointment.price,
                            )}
                          </span>
                        </div>

                        {appointment.clientFeedback && (
                          <div className="mt-3 p-3 bg-muted rounded-lg">
                            <div className="flex items-center space-x-1 mb-1">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star
                                  key={star}
                                  className={`h-4 w-4 ${
                                    star <= appointment.clientFeedback.rating
                                      ? "text-yellow-400 fill-current"
                                      : "text-gray-300"
                                  }`}
                                />
                              ))}
                              <span className="text-sm text-muted-foreground ml-2">Sua avaliação</span>
                            </div>
                            {appointment.clientFeedback.comment && (
                              <p className="text-sm text-muted-foreground">"{appointment.clientFeedback.comment}"</p>
                            )}
                          </div>
                        )}
                      </div>

                      <div className="flex flex-col space-y-2">
                        {appointment.status === "completed" && !appointment.clientFeedback && (
                          <button
                            onClick={() => handleRateAppointment(appointment)}
                            className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm hover:bg-primary/90 transition-colors"
                          >
                            Avaliar Consulta
                          </button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Dialog de Avaliação */}
          {showRatingDialog && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
              <div className="bg-background rounded-lg p-6 w-full max-w-md">
                <h3 className="text-lg font-semibold mb-4">Avaliar Consulta</h3>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Avaliação</label>
                    <div className="flex items-center space-x-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onClick={() => setRatingData({ ...ratingData, rating: star })}
                          className="p-1"
                        >
                          <Star
                            className={`h-6 w-6 ${
                              star <= ratingData.rating ? "text-yellow-400 fill-current" : "text-gray-300"
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Comentário (opcional)</label>
                    <textarea
                      value={ratingData.comment}
                      onChange={(e) => setRatingData({ ...ratingData, comment: e.target.value })}
                      placeholder="Compartilhe sua experiência..."
                      className="w-full p-3 border border-input rounded-md resize-none"
                      rows={3}
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-2 mt-6">
                  <button
                    onClick={() => setShowRatingDialog(false)}
                    className="px-4 py-2 text-muted-foreground hover:text-foreground transition-colors"
                    disabled={ratingLoading}
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={handleSubmitRating}
                    disabled={ratingLoading || ratingData.rating === 0}
                    className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors disabled:opacity-50"
                  >
                    {ratingLoading ? "Enviando..." : "Enviar Avaliação"}
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </ProtectedRoute>
  )
}
