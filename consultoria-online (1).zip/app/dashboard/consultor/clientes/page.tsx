/**
 * Página de gerenciamento de clientes do consultor
 * Lista de clientes e histórico de interações
 */
"use client"

import { useState, useEffect } from "react"
import { appointmentsApi } from "@/lib/api"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Users, Search, Calendar, MessageSquare, Star, Phone, Mail } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface ClientData {
  _id: string
  name: string
  email: string
  avatar?: string
  phone?: string
  totalAppointments: number
  completedAppointments: number
  totalSpent: number
  lastAppointment?: any
  averageRating?: number
}

export default function ConsultorClientes() {
  const [clients, setClients] = useState<ClientData[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    loadClients()
  }, [])

  const loadClients = async () => {
    try {
      setLoading(true)
      const response = await appointmentsApi.getAll({ limit: 100 })
      const appointments = response.data?.appointments || []

      // Agrupa agendamentos por cliente
      const clientsMap = new Map<string, ClientData>()

      appointments.forEach((appointment: any) => {
        const clientId = appointment.client._id
        const client = appointment.client

        if (!clientsMap.has(clientId)) {
          clientsMap.set(clientId, {
            _id: clientId,
            name: client.name,
            email: client.email,
            avatar: client.avatar,
            phone: client.phone,
            totalAppointments: 0,
            completedAppointments: 0,
            totalSpent: 0,
            lastAppointment: null,
            averageRating: 0,
          })
        }

        const clientData = clientsMap.get(clientId)!
        clientData.totalAppointments++

        if (appointment.status === "completed") {
          clientData.completedAppointments++
          clientData.totalSpent += appointment.price
        }

        // Atualiza último agendamento
        if (
          !clientData.lastAppointment ||
          new Date(appointment.scheduledDate) > new Date(clientData.lastAppointment.scheduledDate)
        ) {
          clientData.lastAppointment = appointment
        }

        // Calcula avaliação média (se houver feedback)
        if (appointment.clientFeedback?.rating) {
          const ratings = appointments
            .filter((apt: any) => apt.client._id === clientId && apt.clientFeedback?.rating)
            .map((apt: any) => apt.clientFeedback.rating)

          clientData.averageRating = ratings.reduce((sum: number, rating: number) => sum + rating, 0) / ratings.length
        }
      })

      setClients(Array.from(clientsMap.values()).sort((a, b) => b.totalSpent - a.totalSpent))
    } catch (error) {
      console.error("Erro ao carregar clientes:", error)
    } finally {
      setLoading(false)
    }
  }

  const filteredClients = clients.filter(
    (client) =>
      client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.email.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <ProtectedRoute requiredUserType="consultant">
      <div className="min-h-screen bg-background">
        <Header />

        <main className="container py-8">
          {/* Cabeçalho */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Meus Clientes</h1>
            <p className="text-muted-foreground">Gerencie seus relacionamentos com clientes</p>
          </div>

          {/* Estatísticas */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total de Clientes</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{clients.length}</div>
                <p className="text-xs text-muted-foreground">Clientes únicos atendidos</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Clientes Ativos</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {
                    clients.filter(
                      (client) =>
                        client.lastAppointment &&
                        new Date(client.lastAppointment.scheduledDate) >
                          new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
                    ).length
                  }
                </div>
                <p className="text-xs text-muted-foreground">Últimos 30 dias</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
                <Star className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {new Intl.NumberFormat("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  }).format(clients.reduce((sum, client) => sum + client.totalSpent, 0))}
                </div>
                <p className="text-xs text-muted-foreground">De todos os clientes</p>
              </CardContent>
            </Card>
          </div>

          {/* Busca */}
          <Card className="mb-6">
            <CardHeader>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar clientes por nome ou email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </CardHeader>
          </Card>

          {/* Lista de clientes */}
          <div className="space-y-4">
            {loading ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">Carregando clientes...</p>
                </CardContent>
              </Card>
            ) : filteredClients.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="text-muted-foreground">
                    {searchTerm ? "Nenhum cliente encontrado" : "Você ainda não tem clientes"}
                  </p>
                </CardContent>
              </Card>
            ) : (
              filteredClients.map((client) => (
                <Card key={client._id}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <Avatar className="h-16 w-16">
                          <AvatarImage src={client.avatar || "/placeholder.svg"} />
                          <AvatarFallback className="text-lg">
                            {client.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold text-xl">{client.name}</h3>
                          <div className="flex items-center space-x-4 mt-1">
                            <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                              <Mail className="h-4 w-4" />
                              <span>{client.email}</span>
                            </div>
                            {client.phone && (
                              <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                                <Phone className="h-4 w-4" />
                                <span>{client.phone}</span>
                              </div>
                            )}
                          </div>
                          {client.lastAppointment && (
                            <p className="text-sm text-muted-foreground mt-2">
                              Última consulta:{" "}
                              {format(new Date(client.lastAppointment.scheduledDate), "dd/MM/yyyy", { locale: ptBR })}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="text-right space-y-2">
                        <div className="flex items-center space-x-4">
                          <div className="text-center">
                            <p className="text-2xl font-bold text-primary">
                              {new Intl.NumberFormat("pt-BR", {
                                style: "currency",
                                currency: "BRL",
                              }).format(client.totalSpent)}
                            </p>
                            <p className="text-xs text-muted-foreground">Total gasto</p>
                          </div>
                          <div className="text-center">
                            <p className="text-2xl font-bold">{client.completedAppointments}</p>
                            <p className="text-xs text-muted-foreground">Consultas</p>
                          </div>
                          {client.averageRating > 0 && (
                            <div className="text-center">
                              <div className="flex items-center space-x-1">
                                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                <span className="font-bold">{client.averageRating.toFixed(1)}</span>
                              </div>
                              <p className="text-xs text-muted-foreground">Avaliação</p>
                            </div>
                          )}
                        </div>

                        <div className="flex items-center space-x-2">
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/agendamentos?client=${client._id}`}>
                              <Calendar className="h-4 w-4 mr-1" />
                              Histórico
                            </Link>
                          </Button>
                          {client.lastAppointment?.chatRoomId && (
                            <Button variant="outline" size="sm" asChild>
                              <Link href={`/chat?room=${client.lastAppointment.chatRoomId}`}>
                                <MessageSquare className="h-4 w-4 mr-1" />
                                Chat
                              </Link>
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </main>
      </div>
    </ProtectedRoute>
  )
}
