/**
 * Dashboard principal do consultor
 * Visão geral com métricas, próximos agendamentos e estatísticas
 */
"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { appointmentsApi } from "@/lib/api"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Calendar, Users, DollarSign, Star, Clock, MessageSquare, ChevronRight, CalendarDays } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface DashboardStats {
  totalClients: number
  totalAppointments: number
  monthlyRevenue: number
  averageRating: number
  upcomingAppointments: any[]
  recentAppointments: any[]
}

export default function ConsultorDashboard() {
  const { user } = useAuth()
  const [stats, setStats] = useState<DashboardStats>({
    totalClients: 0,
    totalAppointments: 0,
    monthlyRevenue: 0,
    averageRating: 0,
    upcomingAppointments: [],
    recentAppointments: [],
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadDashboardData()
  }, [])

  const loadDashboardData = async () => {
    try {
      // Busca agendamentos do mês atual
      const currentMonth = new Date()
      const startOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1)
      const endOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0)

      const [upcomingResponse, monthlyResponse, recentResponse] = await Promise.all([
        appointmentsApi.getAll({
          status: "scheduled,confirmed",
          startDate: new Date().toISOString(),
          limit: 5,
        }),
        appointmentsApi.getAll({
          startDate: startOfMonth.toISOString(),
          endDate: endOfMonth.toISOString(),
        }),
        appointmentsApi.getAll({
          status: "completed",
          limit: 5,
        }),
      ])

      const upcomingAppointments = upcomingResponse.data?.appointments || []
      const monthlyAppointments = monthlyResponse.data?.appointments || []
      const recentAppointments = recentResponse.data?.appointments || []

      // Calcula estatísticas
      const completedAppointments = monthlyAppointments.filter((apt: any) => apt.status === "completed")
      const monthlyRevenue = completedAppointments.reduce((sum: number, apt: any) => sum + apt.price, 0)

      // Clientes únicos
      const uniqueClients = new Set(monthlyAppointments.map((apt: any) => apt.client._id))

      setStats({
        totalClients: uniqueClients.size,
        totalAppointments: monthlyAppointments.length,
        monthlyRevenue,
        averageRating: user?.consultantInfo?.rating?.average || 0,
        upcomingAppointments,
        recentAppointments,
      })
    } catch (error) {
      console.error("Erro ao carregar dados do dashboard:", error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      case "confirmed":
        return "bg-green-100 text-green-800"
      case "completed":
        return "bg-gray-100 text-gray-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "scheduled":
        return "Agendado"
      case "confirmed":
        return "Confirmado"
      case "completed":
        return "Concluído"
      case "cancelled":
        return "Cancelado"
      default:
        return status
    }
  }

  return (
    <ProtectedRoute requiredUserType="consultant">
      <div className="min-h-screen bg-background">
        <Header />

        <main className="container py-8">
          {/* Cabeçalho */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Dashboard do Consultor</h1>
            <p className="text-muted-foreground">
              Bem-vindo de volta, {user?.name}! Aqui está um resumo da sua atividade.
            </p>
          </div>

          {/* Cards de métricas */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Clientes este mês</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalClients}</div>
                <p className="text-xs text-muted-foreground">Clientes únicos atendidos</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Consultas este mês</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalAppointments}</div>
                <p className="text-xs text-muted-foreground">Total de agendamentos</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Receita este mês</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {new Intl.NumberFormat("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  }).format(stats.monthlyRevenue)}
                </div>
                <p className="text-xs text-muted-foreground">Consultas concluídas</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avaliação média</CardTitle>
                <Star className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.averageRating.toFixed(1)}</div>
                <div className="flex items-center space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`h-3 w-3 ${
                        star <= stats.averageRating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                      }`}
                    />
                  ))}
                  <span className="text-xs text-muted-foreground ml-1">
                    ({user?.consultantInfo?.rating?.count || 0})
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Próximos agendamentos */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Próximos Agendamentos</CardTitle>
                    <CardDescription>Suas consultas programadas</CardDescription>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <Link href="/dashboard/consultor/agenda">
                      Ver todos
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {stats.upcomingAppointments.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <CalendarDays className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Nenhum agendamento próximo</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {stats.upcomingAppointments.map((appointment: any) => (
                      <div key={appointment._id} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={appointment.client.avatar || "/placeholder.svg"} />
                          <AvatarFallback>
                            {appointment.client.name
                              .split(" ")
                              .map((n: string) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{appointment.title}</p>
                          <p className="text-sm text-muted-foreground">com {appointment.client.name}</p>
                          <div className="flex items-center space-x-2 mt-1">
                            <Clock className="h-3 w-3 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">
                              {format(new Date(appointment.scheduledDate), "dd/MM 'às' HH:mm", { locale: ptBR })}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getStatusColor(appointment.status)}>
                            {getStatusText(appointment.status)}
                          </Badge>
                          {(appointment.status === "confirmed" || appointment.status === "in-progress") && (
                            <Button size="sm" variant="outline" asChild>
                              <Link href={`/dashboard/consultor/chat/${appointment._id}`}>
                                <MessageSquare className="h-4 w-4" />
                              </Link>
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Atividade recente */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Atividade Recente</CardTitle>
                    <CardDescription>Suas consultas concluídas</CardDescription>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <Link href="/dashboard/consultor/historico">
                      Ver histórico
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {stats.recentAppointments.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Nenhuma consulta concluída ainda</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {stats.recentAppointments.map((appointment: any) => (
                      <div key={appointment._id} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={appointment.client.avatar || "/placeholder.svg"} />
                          <AvatarFallback>
                            {appointment.client.name
                              .split(" ")
                              .map((n: string) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{appointment.title}</p>
                          <p className="text-sm text-muted-foreground">com {appointment.client.name}</p>
                          <div className="flex items-center space-x-2 mt-1">
                            <Clock className="h-3 w-3 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">
                              {format(new Date(appointment.scheduledDate), "dd/MM/yyyy", { locale: ptBR })}
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-primary">
                            {new Intl.NumberFormat("pt-BR", {
                              style: "currency",
                              currency: "BRL",
                            }).format(appointment.price)}
                          </p>
                          {appointment.clientFeedback?.rating && (
                            <div className="flex items-center space-x-1">
                              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                              <span className="text-xs">{appointment.clientFeedback.rating}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Ações rápidas */}
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Ações Rápidas</CardTitle>
              <CardDescription>Acesse rapidamente as principais funcionalidades</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Button variant="outline" className="h-20 flex-col space-y-2 bg-transparent" asChild>
                  <Link href="/dashboard/consultor/agenda">
                    <Calendar className="h-6 w-6" />
                    <span>Gerenciar Agenda</span>
                  </Link>
                </Button>
                <Button variant="outline" className="h-20 flex-col space-y-2 bg-transparent" asChild>
                  <Link href="/dashboard/consultor/clientes">
                    <Users className="h-6 w-6" />
                    <span>Ver Clientes</span>
                  </Link>
                </Button>
                <Button variant="outline" className="h-20 flex-col space-y-2 bg-transparent" asChild>
                  <Link href="/dashboard/consultor/chats">
                    <MessageSquare className="h-6 w-6" />
                    <span>Chats Ativos</span>
                  </Link>
                </Button>
                <Button variant="outline" className="h-20 flex-col space-y-2 bg-transparent" asChild>
                  <Link href="/dashboard/consultor/historico">
                    <DollarSign className="h-6 w-6" />
                    <span>Relatórios</span>
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </ProtectedRoute>
  )
}
