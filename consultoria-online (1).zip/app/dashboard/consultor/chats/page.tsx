/**
 * Página de chats ativos do consultor
 * Lista de conversas em andamento
 */
"use client"

import { ProtectedRoute } from "@/components/auth/protected-route"
import { Header } from "@/components/layout/header"
import { ChatList } from "@/components/chat/chat-list"

export default function ConsultorChats() {
  return (
    <ProtectedRoute requiredUserType="consultant">
      <div className="min-h-screen bg-background">
        <Header />

        <main className="container py-8">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold mb-2">Chats Ativos</h1>
              <p className="text-muted-foreground">Suas conversas com clientes</p>
            </div>

            <ChatList userType="consultant" />
          </div>
        </main>
      </div>
    </ProtectedRoute>
  )
}
