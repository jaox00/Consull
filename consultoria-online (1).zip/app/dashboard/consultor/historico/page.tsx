/**
 * Página de histórico de atendimentos do consultor
 * Relatórios e análises de performance
 */
"use client"

import { useState, useEffect } from "react"
import { appointmentsApi } from "@/lib/api"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts"
import { Calendar, DollarSign, Star, TrendingUp, FileText, Download } from "lucide-react"
import { format, subMonths, startOfMonth, endOfMonth } from "date-fns"
import { ptBR } from "date-fns/locale"

export default function ConsultorHistorico() {
  const [appointments, setAppointments] = useState([])
  const [loading, setLoading] = useState(true)
  const [period, setPeriod] = useState("6months")
  const [chartData, setChartData] = useState([])
  const [stats, setStats] = useState({
    totalRevenue: 0,
    totalAppointments: 0,
    averageRating: 0,
    completionRate: 0,
  })

  useEffect(() => {
    loadHistoryData()
  }, [period])

  const loadHistoryData = async () => {
    try {
      setLoading(true)
      const months = period === "3months" ? 3 : period === "6months" ? 6 : 12
      const startDate = startOfMonth(subMonths(new Date(), months - 1))

      const response = await appointmentsApi.getAll({
        startDate: startDate.toISOString(),
        limit: 500,
      })

      const appointmentsList = response.data?.appointments || []
      setAppointments(appointmentsList)

      // Calcula estatísticas
      const completedAppointments = appointmentsList.filter((apt: any) => apt.status === "completed")
      const totalRevenue = completedAppointments.reduce((sum: number, apt: any) => sum + apt.price, 0)

      const ratingsWithFeedback = completedAppointments.filter((apt: any) => apt.clientFeedback?.rating)
      const averageRating =
        ratingsWithFeedback.length > 0
          ? ratingsWithFeedback.reduce((sum: number, apt: any) => sum + apt.clientFeedback.rating, 0) /
            ratingsWithFeedback.length
          : 0

      const completionRate =
        appointmentsList.length > 0 ? (completedAppointments.length / appointmentsList.length) * 100 : 0

      setStats({
        totalRevenue,
        totalAppointments: appointmentsList.length,
        averageRating,
        completionRate,
      })

      // Prepara dados para gráficos
      const monthlyData = []
      for (let i = months - 1; i >= 0; i--) {
        const monthStart = startOfMonth(subMonths(new Date(), i))
        const monthEnd = endOfMonth(monthStart)

        const monthAppointments = appointmentsList.filter((apt: any) => {
          const aptDate = new Date(apt.scheduledDate)
          return aptDate >= monthStart && aptDate <= monthEnd
        })

        const monthCompleted = monthAppointments.filter((apt: any) => apt.status === "completed")
        const monthRevenue = monthCompleted.reduce((sum: number, apt: any) => sum + apt.price, 0)

        monthlyData.push({
          month: format(monthStart, "MMM/yy", { locale: ptBR }),
          appointments: monthAppointments.length,
          completed: monthCompleted.length,
          revenue: monthRevenue,
        })
      }

      setChartData(monthlyData)
    } catch (error) {
      console.error("Erro ao carregar histórico:", error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed":
        return "Concluído"
      case "cancelled":
        return "Cancelado"
      default:
        return status
    }
  }

  return (
    <ProtectedRoute requiredUserType="consultant">
      <div className="min-h-screen bg-background">
        <Header />

        <main className="container py-8">
          {/* Cabeçalho */}
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Histórico e Relatórios</h1>
              <p className="text-muted-foreground">Análise da sua performance e histórico de atendimentos</p>
            </div>
            <div className="flex items-center space-x-4">
              <Select value={period} onValueChange={setPeriod}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3months">Últimos 3 meses</SelectItem>
                  <SelectItem value="6months">Últimos 6 meses</SelectItem>
                  <SelectItem value="12months">Último ano</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Exportar
              </Button>
            </div>
          </div>

          {/* Cards de estatísticas */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {new Intl.NumberFormat("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  }).format(stats.totalRevenue)}
                </div>
                <p className="text-xs text-muted-foreground">No período selecionado</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total de Consultas</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalAppointments}</div>
                <p className="text-xs text-muted-foreground">Agendamentos realizados</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avaliação Média</CardTitle>
                <Star className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.averageRating.toFixed(1)}</div>
                <div className="flex items-center space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`h-3 w-3 ${
                        star <= stats.averageRating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Taxa de Conclusão</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.completionRate.toFixed(1)}%</div>
                <p className="text-xs text-muted-foreground">Consultas concluídas</p>
              </CardContent>
            </Card>
          </div>

          {/* Gráficos */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Receita Mensal</CardTitle>
                <CardDescription>Evolução da receita ao longo do tempo</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip
                      formatter={(value: number) =>
                        new Intl.NumberFormat("pt-BR", {
                          style: "currency",
                          currency: "BRL",
                        }).format(value)
                      }
                    />
                    <Line type="monotone" dataKey="revenue" stroke="#059669" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Consultas por Mês</CardTitle>
                <CardDescription>Número de consultas agendadas e concluídas</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="appointments" fill="#10b981" name="Agendadas" />
                    <Bar dataKey="completed" fill="#059669" name="Concluídas" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Lista de consultas recentes */}
          <Card>
            <CardHeader>
              <CardTitle>Consultas Recentes</CardTitle>
              <CardDescription>Histórico detalhado dos seus atendimentos</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="py-8 text-center">
                  <p className="text-muted-foreground">Carregando histórico...</p>
                </div>
              ) : appointments.length === 0 ? (
                <div className="py-8 text-center">
                  <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="text-muted-foreground">Nenhuma consulta encontrada no período</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {appointments.slice(0, 10).map((appointment: any) => (
                    <div key={appointment._id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={appointment.client.avatar || "/placeholder.svg"} />
                          <AvatarFallback>
                            {appointment.client.name
                              .split(" ")
                              .map((n: string) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{appointment.title}</p>
                          <p className="text-sm text-muted-foreground">com {appointment.client.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {format(new Date(appointment.scheduledDate), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <p className="font-medium">
                            {new Intl.NumberFormat("pt-BR", {
                              style: "currency",
                              currency: "BRL",
                            }).format(appointment.price)}
                          </p>
                          {appointment.clientFeedback?.rating && (
                            <div className="flex items-center space-x-1">
                              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                              <span className="text-xs">{appointment.clientFeedback.rating}</span>
                            </div>
                          )}
                        </div>
                        <Badge className={getStatusColor(appointment.status)}>
                          {getStatusText(appointment.status)}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </ProtectedRoute>
  )
}
