/**
 * Página de agenda do consultor
 * Visualização e gerenciamento de agendamentos
 */
"use client"

import { useState, useEffect } from "react"
import { appointmentsApi } from "@/lib/api"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { Header } from "@/components/layout/header"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, Clock, Search, Filter, ChevronLeft, ChevronRight, Eye, MessageSquare } from "lucide-react"
import Link from "next/link"
import { format, startOfWeek, endOfWeek, addWeeks, subWeeks } from "date-fns"
import { ptBR } from "date-fns/locale"

export default function ConsultorAgenda() {
  const [appointments, setAppointments] = useState([])
  const [loading, setLoading] = useState(true)
  const [currentWeek, setCurrentWeek] = useState(new Date())
  const [statusFilter, setStatusFilter] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    loadAppointments()
  }, [currentWeek, statusFilter])

  const loadAppointments = async () => {
    try {
      setLoading(true)
      const weekStart = startOfWeek(currentWeek, { weekStartsOn: 1 })
      const weekEnd = endOfWeek(currentWeek, { weekStartsOn: 1 })

      const params: any = {
        startDate: weekStart.toISOString(),
        endDate: weekEnd.toISOString(),
        limit: 50,
      }

      if (statusFilter !== "all") {
        params.status = statusFilter
      }

      const response = await appointmentsApi.getAll(params)
      setAppointments(response.data?.appointments || [])
    } catch (error) {
      console.error("Erro ao carregar agendamentos:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleStatusChange = async (appointmentId: string, newStatus: string) => {
    try {
      await appointmentsApi.updateStatus(appointmentId, newStatus)
      loadAppointments()
    } catch (error) {
      console.error("Erro ao atualizar status:", error)
    }
  }

  const filteredAppointments = appointments.filter(
    (appointment: any) =>
      appointment.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      appointment.client.name.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      case "confirmed":
        return "bg-green-100 text-green-800"
      case "in-progress":
        return "bg-yellow-100 text-yellow-800"
      case "completed":
        return "bg-gray-100 text-gray-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "scheduled":
        return "Agendado"
      case "confirmed":
        return "Confirmado"
      case "in-progress":
        return "Em andamento"
      case "completed":
        return "Concluído"
      case "cancelled":
        return "Cancelado"
      default:
        return status
    }
  }

  return (
    <ProtectedRoute requiredUserType="consultant">
      <div className="min-h-screen bg-background">
        <Header />

        <main className="container py-8">
          {/* Cabeçalho */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Agenda</h1>
            <p className="text-muted-foreground">Gerencie seus agendamentos e disponibilidade</p>
          </div>

          {/* Controles */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                {/* Navegação de semana */}
                <div className="flex items-center space-x-4">
                  <Button variant="outline" size="sm" onClick={() => setCurrentWeek(subWeeks(currentWeek, 1))}>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <div className="text-center">
                    <p className="font-medium">
                      {format(startOfWeek(currentWeek, { weekStartsOn: 1 }), "dd/MM", { locale: ptBR })} -{" "}
                      {format(endOfWeek(currentWeek, { weekStartsOn: 1 }), "dd/MM/yyyy", { locale: ptBR })}
                    </p>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setCurrentWeek(addWeeks(currentWeek, 1))}>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setCurrentWeek(new Date())}>
                    Hoje
                  </Button>
                </div>

                {/* Filtros */}
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Buscar agendamentos..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-40">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="scheduled">Agendados</SelectItem>
                      <SelectItem value="confirmed">Confirmados</SelectItem>
                      <SelectItem value="in-progress">Em andamento</SelectItem>
                      <SelectItem value="completed">Concluídos</SelectItem>
                      <SelectItem value="cancelled">Cancelados</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Lista de agendamentos */}
          <div className="space-y-4">
            {loading ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">Carregando agendamentos...</p>
                </CardContent>
              </Card>
            ) : filteredAppointments.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="text-muted-foreground">Nenhum agendamento encontrado para este período</p>
                </CardContent>
              </Card>
            ) : (
              filteredAppointments.map((appointment: any) => (
                <Card key={appointment._id}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={appointment.client.avatar || "/placeholder.svg"} />
                          <AvatarFallback>
                            {appointment.client.name
                              .split(" ")
                              .map((n: string) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold text-lg">{appointment.title}</h3>
                          <p className="text-muted-foreground">Cliente: {appointment.client.name}</p>
                          <div className="flex items-center space-x-4 mt-2">
                            <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                              <Calendar className="h-4 w-4" />
                              <span>{format(new Date(appointment.scheduledDate), "dd/MM/yyyy", { locale: ptBR })}</span>
                            </div>
                            <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                              <Clock className="h-4 w-4" />
                              <span>
                                {format(new Date(appointment.scheduledDate), "HH:mm", { locale: ptBR })} (
                                {appointment.duration}min)
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <p className="font-semibold text-lg text-primary">
                            {new Intl.NumberFormat("pt-BR", {
                              style: "currency",
                              currency: "BRL",
                            }).format(appointment.price)}
                          </p>
                          <Badge className={getStatusColor(appointment.status)}>
                            {getStatusText(appointment.status)}
                          </Badge>
                        </div>

                        <div className="flex items-center space-x-2">
                          {appointment.status === "scheduled" && (
                            <Button
                              size="sm"
                              onClick={() => handleStatusChange(appointment._id, "confirmed")}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              Confirmar
                            </Button>
                          )}
                          {appointment.status === "confirmed" && (
                            <Button
                              size="sm"
                              onClick={() => handleStatusChange(appointment._id, "in-progress")}
                              className="bg-yellow-600 hover:bg-yellow-700"
                            >
                              Iniciar
                            </Button>
                          )}
                          {appointment.status === "in-progress" && (
                            <Button
                              size="sm"
                              onClick={() => handleStatusChange(appointment._id, "completed")}
                              className="bg-gray-600 hover:bg-gray-700"
                            >
                              Concluir
                            </Button>
                          )}
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/agendamentos/${appointment._id}`}>
                              <Eye className="h-4 w-4" />
                            </Link>
                          </Button>
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/chat?room=${appointment.chatRoomId}`}>
                              <MessageSquare className="h-4 w-4" />
                            </Link>
                          </Button>
                        </div>
                      </div>
                    </div>

                    {appointment.description && (
                      <div className="mt-4 p-4 bg-muted/50 rounded-lg">
                        <p className="text-sm">{appointment.description}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </main>
      </div>
    </ProtectedRoute>
  )
}
