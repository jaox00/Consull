/**
 * Dashboard principal - redireciona baseado no tipo de usuário
 */
"use client"

import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { Loader2 } from "lucide-react"

export default function DashboardPage() {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && user) {
      if (user.userType === "consultant") {
        router.push("/dashboard/consultor")
      } else if (user.userType === "client") {
        router.push("/dashboard/cliente")
      }
    } else if (!loading && !user) {
      router.push("/auth/login")
    }
  }, [user, loading, router])

  return (
    <div className="min-h-screen flex items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin" />
    </div>
  )
}
