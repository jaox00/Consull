/**
 * Página de cadastro
 * Formulário para criação de novas contas (clientes e consultores)
 */
"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2, ArrowLeft, User, Briefcase } from "lucide-react"

export default function RegisterPage() {
  const [userType, setUserType] = useState<"client" | "consultant">("client")
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    phone: "",
    bio: "",
    // Campos específicos para consultores
    specialties: "",
    experience: "",
    hourlyRate: "",
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const { register } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()

  // Define tipo baseado na URL
  useEffect(() => {
    const type = searchParams.get("type")
    if (type === "consultant") {
      setUserType("consultant")
    }
  }, [searchParams])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    // Validações
    if (formData.password !== formData.confirmPassword) {
      setError("As senhas não coincidem")
      setLoading(false)
      return
    }

    if (formData.password.length < 6) {
      setError("A senha deve ter pelo menos 6 caracteres")
      setLoading(false)
      return
    }

    try {
      const userData: any = {
        name: formData.name,
        email: formData.email,
        password: formData.password,
        userType,
        phone: formData.phone,
        bio: formData.bio,
      }

      // Adiciona campos específicos para consultores
      if (userType === "consultant") {
        userData.specialties = formData.specialties
          .split(",")
          .map((s) => s.trim())
          .filter((s) => s)
        userData.experience = Number.parseInt(formData.experience) || 0
        userData.hourlyRate = Number.parseFloat(formData.hourlyRate) || 0
      }

      const success = await register(userData)
      if (success) {
        router.push("/dashboard")
      }
    } catch (err) {
      setError("Erro ao criar conta. Tente novamente.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/50 p-4">
      <div className="w-full max-w-md">
        {/* Botão voltar */}
        <Button variant="ghost" asChild className="mb-4">
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar ao início
          </Link>
        </Button>

        <Card>
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="h-12 w-12 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">CP</span>
              </div>
            </div>
            <CardTitle className="text-2xl">Criar sua conta</CardTitle>
            <CardDescription>Escolha o tipo de conta e preencha seus dados</CardDescription>
          </CardHeader>

          <CardContent>
            {/* Seletor de tipo de usuário */}
            <Tabs
              value={userType}
              onValueChange={(value) => setUserType(value as "client" | "consultant")}
              className="mb-6"
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="client" className="flex items-center space-x-2">
                  <User className="h-4 w-4" />
                  <span>Cliente</span>
                </TabsTrigger>
                <TabsTrigger value="consultant" className="flex items-center space-x-2">
                  <Briefcase className="h-4 w-4" />
                  <span>Consultor</span>
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {/* Campos básicos */}
              <div className="space-y-2">
                <Label htmlFor="name">Nome completo</Label>
                <Input
                  id="name"
                  name="name"
                  type="text"
                  placeholder="Seu nome completo"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  disabled={loading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="seu@email.com"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  disabled={loading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Telefone (opcional)</Label>
                <Input
                  id="phone"
                  name="phone"
                  type="tel"
                  placeholder="(11) 99999-9999"
                  value={formData.phone}
                  onChange={handleInputChange}
                  disabled={loading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Senha</Label>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  placeholder="Mínimo 6 caracteres"
                  value={formData.password}
                  onChange={handleInputChange}
                  required
                  disabled={loading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirmar senha</Label>
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  placeholder="Digite a senha novamente"
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                  required
                  disabled={loading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Sobre você (opcional)</Label>
                <Textarea
                  id="bio"
                  name="bio"
                  placeholder="Conte um pouco sobre você..."
                  value={formData.bio}
                  onChange={handleInputChange}
                  disabled={loading}
                  rows={3}
                />
              </div>

              {/* Campos específicos para consultores */}
              {userType === "consultant" && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="specialties">Especialidades</Label>
                    <Input
                      id="specialties"
                      name="specialties"
                      type="text"
                      placeholder="Marketing, Vendas, Estratégia (separadas por vírgula)"
                      value={formData.specialties}
                      onChange={handleInputChange}
                      disabled={loading}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="experience">Anos de experiência</Label>
                      <Input
                        id="experience"
                        name="experience"
                        type="number"
                        placeholder="5"
                        value={formData.experience}
                        onChange={handleInputChange}
                        disabled={loading}
                        min="0"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="hourlyRate">Taxa por hora (R$)</Label>
                      <Input
                        id="hourlyRate"
                        name="hourlyRate"
                        type="number"
                        placeholder="150"
                        value={formData.hourlyRate}
                        onChange={handleInputChange}
                        disabled={loading}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </div>
                </>
              )}

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Criando conta...
                  </>
                ) : (
                  `Criar conta ${userType === "consultant" ? "de Consultor" : "de Cliente"}`
                )}
              </Button>
            </form>

            <div className="mt-6 text-center text-sm">
              <span className="text-muted-foreground">Já tem uma conta? </span>
              <Link href="/auth/login" className="text-primary hover:underline">
                Faça login aqui
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
