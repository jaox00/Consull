/**
 * Página inicial (Landing Page)
 * Apresenta os serviços e benefícios da plataforma
 */

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { Users, Calendar, MessageSquare, Shield, Star, Clock, ArrowRight, Zap } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-20 px-4 bg-gradient-to-br from-background to-muted/50">
          <div className="container max-w-6xl mx-auto text-center">
            <Badge variant="secondary" className="mb-4">
              Plataforma de Consultoria Online
            </Badge>

            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance">
              Conecte-se com
              <span className="text-primary"> Especialistas</span>
              <br />
              ou Ofereça sua
              <span className="text-primary"> Expertise</span>
            </h1>

            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto text-pretty">
              A plataforma que conecta consultores qualificados com clientes que precisam de orientação profissional.
              Agendamento fácil, chat em tempo real e pagamentos seguros.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link href="/consultores">
                  Encontrar Consultores
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/auth/register?type=consultant">Tornar-se Consultor</Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 px-4">
          <div className="container max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Como Funciona</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Processo simples e seguro para conectar consultores e clientes
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="text-center">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>1. Encontre o Especialista</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Navegue por nossa rede de consultores qualificados, filtre por especialidade e avaliações.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Calendar className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>2. Agende sua Consulta</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Escolha data e horário disponíveis, defina o escopo da consultoria e confirme o agendamento.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <MessageSquare className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>3. Converse em Tempo Real</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Use nosso sistema de chat integrado para se comunicar antes, durante e após a consultoria.
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-20 px-4 bg-muted/50">
          <div className="container max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-6">Por que Escolher a ConsultPro?</h2>

                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Shield className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">Segurança Garantida</h3>
                      <p className="text-muted-foreground">
                        Todos os consultores são verificados e os pagamentos são processados com segurança.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Star className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">Qualidade Comprovada</h3>
                      <p className="text-muted-foreground">
                        Sistema de avaliações e feedback para garantir a melhor experiência.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Clock className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">Flexibilidade Total</h3>
                      <p className="text-muted-foreground">
                        Agende consultas no seu tempo, com cancelamento fácil quando necessário.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Zap className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">Resultados Rápidos</h3>
                      <p className="text-muted-foreground">
                        Conecte-se instantaneamente com especialistas e obtenha respostas imediatas.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="relative">
                <div className="bg-card border rounded-lg p-6 shadow-lg">
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                      <span className="text-primary-foreground font-bold">JD</span>
                    </div>
                    <div>
                      <h4 className="font-semibold">João Silva</h4>
                      <p className="text-sm text-muted-foreground">Consultor em Marketing Digital</p>
                    </div>
                    <Badge>Verificado</Badge>
                  </div>

                  <div className="flex items-center space-x-1 mb-3">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                    <span className="text-sm text-muted-foreground ml-2">(127 avaliações)</span>
                  </div>

                  <p className="text-sm text-muted-foreground mb-4">
                    "Excelente plataforma! Consegui conectar com clientes qualificados e aumentar minha receita em 300%
                    nos últimos 6 meses."
                  </p>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Taxa por hora:</span>
                    <span className="font-semibold text-primary">R$ 150/h</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-20 px-4">
          <div className="container max-w-6xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
              <div>
                <div className="text-4xl font-bold text-primary mb-2">500+</div>
                <div className="text-muted-foreground">Consultores Ativos</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-primary mb-2">2.5k+</div>
                <div className="text-muted-foreground">Consultas Realizadas</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-primary mb-2">4.8</div>
                <div className="text-muted-foreground">Avaliação Média</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-primary mb-2">98%</div>
                <div className="text-muted-foreground">Satisfação dos Clientes</div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-4 bg-primary text-primary-foreground">
          <div className="container max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Pronto para Começar?</h2>
            <p className="text-xl mb-8 opacity-90">
              Junte-se a milhares de profissionais que já estão transformando suas carreiras na ConsultPro.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" asChild>
                <Link href="/auth/register">Criar Conta Gratuita</Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary bg-transparent"
                asChild
              >
                <Link href="/consultores">Explorar Consultores</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
