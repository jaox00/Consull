/**
 * Contexto de autenticação global
 * Gerencia estado do usuário logado e funções de auth
 */
"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "@/hooks/use-toast"

interface User {
  _id: string
  name: string
  email: string
  userType: "client" | "consultant"
  avatar?: string
  phone?: string
  bio?: string
  consultantInfo?: {
    specialties: string[]
    experience: number
    hourlyRate: number
    rating: {
      average: number
      count: number
    }
  }
  isActive: boolean
  isVerified: boolean
}

interface AuthContextType {
  user: User | null
  token: string | null
  loading: boolean
  login: (email: string, password: string) => Promise<boolean>
  register: (userData: RegisterData) => Promise<boolean>
  logout: () => void
  updateUser: (userData: Partial<User>) => void
}

interface RegisterData {
  name: string
  email: string
  password: string
  userType: "client" | "consultant"
  phone?: string
  bio?: string
  specialties?: string[]
  experience?: number
  hourlyRate?: number
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000"

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [token, setToken] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  // Carrega dados do usuário do localStorage na inicialização
  useEffect(() => {
    const savedToken = localStorage.getItem("auth_token")
    const savedUser = localStorage.getItem("auth_user")

    if (savedToken && savedUser) {
      setToken(savedToken)
      setUser(JSON.parse(savedUser))
      // Verifica se o token ainda é válido
      verifyToken(savedToken)
    } else {
      setLoading(false)
    }
  }, [])

  // Verifica se o token ainda é válido
  const verifyToken = async (authToken: string) => {
    try {
      const response = await fetch(`${API_URL}/api/auth/me`, {
        headers: {
          Authorization: `Bearer ${authToken}`,
          "Content-Type": "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()
        setUser(data.data.user)
      } else {
        // Token inválido, remove do storage
        localStorage.removeItem("auth_token")
        localStorage.removeItem("auth_user")
        setToken(null)
        setUser(null)
      }
    } catch (error) {
      console.error("Erro ao verificar token:", error)
      localStorage.removeItem("auth_token")
      localStorage.removeItem("auth_user")
      setToken(null)
      setUser(null)
    } finally {
      setLoading(false)
    }
  }

  // Função de login
  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const response = await fetch(`${API_URL}/api/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      })

      const data = await response.json()

      if (response.ok) {
        const { user: userData, token: authToken } = data.data

        setUser(userData)
        setToken(authToken)

        // Salva no localStorage
        localStorage.setItem("auth_token", authToken)
        localStorage.setItem("auth_user", JSON.stringify(userData))

        toast({
          title: "Login realizado com sucesso!",
          description: `Bem-vindo(a), ${userData.name}`,
        })

        return true
      } else {
        toast({
          title: "Erro no login",
          description: data.message || "Credenciais inválidas",
          variant: "destructive",
        })
        return false
      }
    } catch (error) {
      console.error("Erro no login:", error)
      toast({
        title: "Erro no login",
        description: "Erro de conexão. Tente novamente.",
        variant: "destructive",
      })
      return false
    }
  }

  // Função de cadastro
  const register = async (userData: RegisterData): Promise<boolean> => {
    try {
      const response = await fetch(`${API_URL}/api/auth/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
      })

      const data = await response.json()

      if (response.ok) {
        const { user: newUser, token: authToken } = data.data

        setUser(newUser)
        setToken(authToken)

        // Salva no localStorage
        localStorage.setItem("auth_token", authToken)
        localStorage.setItem("auth_user", JSON.stringify(newUser))

        toast({
          title: "Cadastro realizado com sucesso!",
          description: `Bem-vindo(a) à plataforma, ${newUser.name}`,
        })

        return true
      } else {
        toast({
          title: "Erro no cadastro",
          description: data.message || "Erro ao criar conta",
          variant: "destructive",
        })
        return false
      }
    } catch (error) {
      console.error("Erro no cadastro:", error)
      toast({
        title: "Erro no cadastro",
        description: "Erro de conexão. Tente novamente.",
        variant: "destructive",
      })
      return false
    }
  }

  // Função de logout
  const logout = () => {
    setUser(null)
    setToken(null)
    localStorage.removeItem("auth_token")
    localStorage.removeItem("auth_user")

    toast({
      title: "Logout realizado",
      description: "Você foi desconectado com sucesso",
    })

    router.push("/")
  }

  // Função para atualizar dados do usuário
  const updateUser = (userData: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...userData }
      setUser(updatedUser)
      localStorage.setItem("auth_user", JSON.stringify(updatedUser))
    }
  }

  const value = {
    user,
    token,
    loading,
    login,
    register,
    logout,
    updateUser,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

// Hook para usar o contexto de autenticação
export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth deve ser usado dentro de um AuthProvider")
  }
  return context
}
