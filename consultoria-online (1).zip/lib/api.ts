/**
 * Utilitários para chamadas à API
 * Configuração centralizada com interceptadores
 */

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000"

interface ApiResponse<T = any> {
  success: boolean
  message: string
  data?: T
  errors?: any[]
}

class ApiClient {
  private baseURL: string

  constructor(baseURL: string) {
    this.baseURL = baseURL
  }

  private getAuthHeaders(): HeadersInit {
    const token = localStorage.getItem("auth_token")
    return {
      "Content-Type": "application/json",
      ...(token && { Authorization: `Bearer ${token}` }),
    }
  }

  private async handleResponse<T>(response: Response): Promise<ApiResponse<T>> {
    const data = await response.json()

    if (!response.ok) {
      // Se token expirou, redireciona para login
      if (response.status === 401) {
        localStorage.removeItem("auth_token")
        localStorage.removeItem("auth_user")
        window.location.href = "/auth/login"
      }
      throw new Error(data.message || "Erro na requisição")
    }

    return data
  }

  async get<T>(endpoint: string): Promise<ApiResponse<T>> {
    const response = await fetch(`${this.baseURL}${endpoint}`, {
      method: "GET",
      headers: this.getAuthHeaders(),
    })
    return this.handleResponse<T>(response)
  }

  async post<T>(endpoint: string, data?: any): Promise<ApiResponse<T>> {
    const response = await fetch(`${this.baseURL}${endpoint}`, {
      method: "POST",
      headers: this.getAuthHeaders(),
      body: data ? JSON.stringify(data) : undefined,
    })
    return this.handleResponse<T>(response)
  }

  async put<T>(endpoint: string, data?: any): Promise<ApiResponse<T>> {
    const response = await fetch(`${this.baseURL}${endpoint}`, {
      method: "PUT",
      headers: this.getAuthHeaders(),
      body: data ? JSON.stringify(data) : undefined,
    })
    return this.handleResponse<T>(response)
  }

  async delete<T>(endpoint: string): Promise<ApiResponse<T>> {
    const response = await fetch(`${this.baseURL}${endpoint}`, {
      method: "DELETE",
      headers: this.getAuthHeaders(),
    })
    return this.handleResponse<T>(response)
  }
}

export const api = new ApiClient(API_URL)

// Funções específicas da API
export const authApi = {
  login: (email: string, password: string) => api.post("/api/auth/login", { email, password }),

  register: (userData: any) => api.post("/api/auth/register", userData),

  getProfile: () => api.get("/api/auth/me"),

  refreshToken: () => api.post("/api/auth/refresh"),
}

export const usersApi = {
  getConsultants: (params?: any) => api.get(`/api/users/consultants${params ? `?${new URLSearchParams(params)}` : ""}`),

  getProfile: () => api.get("/api/users/profile"),

  updateProfile: (data: any) => api.put("/api/users/profile", data),

  getUserById: (id: string) => api.get(`/api/users/${id}`),

  changePassword: (currentPassword: string, newPassword: string) =>
    api.put("/api/users/change-password", { currentPassword, newPassword }),
}

export const appointmentsApi = {
  create: (data: any) => api.post("/api/appointments", data),

  getAll: (params?: any) => api.get(`/api/appointments${params ? `?${new URLSearchParams(params)}` : ""}`),

  getById: (id: string) => api.get(`/api/appointments/${id}`),

  updateStatus: (id: string, status: string, reason?: string) =>
    api.put(`/api/appointments/${id}/status`, { status, reason }),

  addFeedback: (id: string, rating: number, comment?: string) =>
    api.post(`/api/appointments/${id}/feedback`, { rating, comment }),
}

export const chatApi = {
  getMessages: (roomId: string, params?: any) =>
    api.get(`/api/chat/${roomId}/messages${params ? `?${new URLSearchParams(params)}` : ""}`),

  sendMessage: (roomId: string, content: string, messageType?: string, fileInfo?: any) =>
    api.post(`/api/chat/${roomId}/messages`, { content, messageType, fileInfo }),

  getRooms: () => api.get("/api/chat/rooms"),
}
