/**
 * Configuração do Socket.IO para chat em tempo real
 * Gerencia conexões e eventos de mensagens
 */
"use client"

import { io, type Socket } from "socket.io-client"

class SocketService {
  private socket: Socket | null = null
  private isConnected = false

  connect(token: string): Socket {
    if (!this.socket || !this.isConnected) {
      this.socket = io(process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000", {
        auth: {
          token,
        },
        transports: ["websocket", "polling"],
      })

      this.socket.on("connect", () => {
        console.log("[v0] Socket conectado:", this.socket?.id)
        this.isConnected = true
      })

      this.socket.on("disconnect", () => {
        console.log("[v0] Socket desconectado")
        this.isConnected = false
      })

      this.socket.on("connect_error", (error) => {
        console.error("[v0] Erro de conexão:", error)
        this.isConnected = false
      })
    }

    return this.socket
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect()
      this.socket = null
      this.isConnected = false
    }
  }

  getSocket(): Socket | null {
    return this.socket
  }

  isSocketConnected(): boolean {
    return this.isConnected && this.socket?.connected === true
  }

  // Métodos específicos do chat
  joinChatRoom(appointmentId: string) {
    if (this.socket) {
      this.socket.emit("join_chat", { appointmentId })
    }
  }

  leaveChatRoom(appointmentId: string) {
    if (this.socket) {
      this.socket.emit("leave_chat", { appointmentId })
    }
  }

  sendMessage(appointmentId: string, message: string) {
    if (this.socket) {
      this.socket.emit("send_message", {
        appointmentId,
        message,
        timestamp: new Date().toISOString(),
      })
    }
  }

  onNewMessage(callback: (data: any) => void) {
    if (this.socket) {
      this.socket.on("new_message", callback)
    }
  }

  onUserJoined(callback: (data: any) => void) {
    if (this.socket) {
      this.socket.on("user_joined", callback)
    }
  }

  onUserLeft(callback: (data: any) => void) {
    if (this.socket) {
      this.socket.on("user_left", callback)
    }
  }

  offAllListeners() {
    if (this.socket) {
      this.socket.off("new_message")
      this.socket.off("user_joined")
      this.socket.off("user_left")
    }
  }
}

export const socketService = new SocketService()
