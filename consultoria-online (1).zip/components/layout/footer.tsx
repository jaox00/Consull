/**
 * Footer da aplicação
 * Links úteis e informações da empresa
 */

import Link from "next/link"

export function Footer() {
  return (
    <footer className="border-t bg-muted/50">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo e descrição */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">CP</span>
              </div>
              <span className="font-bold text-xl">ConsultPro</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Conectando consultores e clientes de forma profissional e segura.
            </p>
          </div>

          {/* Para Clientes */}
          <div className="space-y-4">
            <h3 className="font-semibold">Para Clientes</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/consultores" className="hover:text-foreground transition-colors">
                  Encontrar Consultores
                </Link>
              </li>
              <li>
                <Link href="/como-funciona" className="hover:text-foreground transition-colors">
                  Como Funciona
                </Link>
              </li>
              <li>
                <Link href="/precos" className="hover:text-foreground transition-colors">
                  Preços
                </Link>
              </li>
            </ul>
          </div>

          {/* Para Consultores */}
          <div className="space-y-4">
            <h3 className="font-semibold">Para Consultores</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/auth/register?type=consultant" className="hover:text-foreground transition-colors">
                  Tornar-se Consultor
                </Link>
              </li>
              <li>
                <Link href="/recursos" className="hover:text-foreground transition-colors">
                  Recursos
                </Link>
              </li>
              <li>
                <Link href="/comissoes" className="hover:text-foreground transition-colors">
                  Comissões
                </Link>
              </li>
            </ul>
          </div>

          {/* Suporte */}
          <div className="space-y-4">
            <h3 className="font-semibold">Suporte</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/ajuda" className="hover:text-foreground transition-colors">
                  Central de Ajuda
                </Link>
              </li>
              <li>
                <Link href="/contato" className="hover:text-foreground transition-colors">
                  Contato
                </Link>
              </li>
              <li>
                <Link href="/termos" className="hover:text-foreground transition-colors">
                  Termos de Uso
                </Link>
              </li>
              <li>
                <Link href="/privacidade" className="hover:text-foreground transition-colors">
                  Privacidade
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t text-center text-sm text-muted-foreground">
          <p>&copy; 2024 ConsultPro. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  )
}
