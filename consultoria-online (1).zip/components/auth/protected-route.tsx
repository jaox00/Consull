/**
 * Componente para proteger rotas que requerem autenticação
 * Redireciona usuários não autenticados para login
 */
"use client"

import type React from "react"

import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { Loader2 } from "lucide-react"

interface ProtectedRouteProps {
  children: React.ReactNode
  requiredUserType?: "client" | "consultant"
  fallbackPath?: string
}

export function ProtectedRoute({ children, requiredUserType, fallbackPath = "/auth/login" }: ProtectedRouteProps) {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading) {
      if (!user) {
        router.push(fallbackPath)
        return
      }

      if (requiredUserType && user.userType !== requiredUserType) {
        router.push("/dashboard")
        return
      }
    }
  }, [user, loading, router, requiredUserType, fallbackPath])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  if (!user || (requiredUserType && user.userType !== requiredUserType)) {
    return null
  }

  return <>{children}</>
}
