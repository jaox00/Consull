/**
 * Componente de janela de chat em tempo real
 * Interface principal para troca de mensagens
 */
"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useAuth } from "@/lib/auth-context"
import { socketService } from "@/lib/socket"
import { chatApi } from "@/lib/api"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { toast } from "@/hooks/use-toast"
import { Send, User, Clock } from "lucide-react"

interface Message {
  _id: string
  sender: {
    _id: string
    name: string
    userType: string
  }
  message: string
  timestamp: string
  read: boolean
}

interface ChatWindowProps {
  appointmentId: string
  otherUser: {
    _id: string
    name: string
    userType: string
  }
}

export function ChatWindow({ appointmentId, otherUser }: ChatWindowProps) {
  const { user, token } = useAuth()
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [otherUserOnline, setOtherUserOnline] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (token) {
      // Conecta ao socket
      const socket = socketService.connect(token)

      socket.on("connect", () => {
        setIsConnected(true)
        socketService.joinChatRoom(appointmentId)
      })

      socket.on("disconnect", () => {
        setIsConnected(false)
        setOtherUserOnline(false)
      })

      // Listeners do chat
      socketService.onNewMessage((data) => {
        console.log("[v0] Nova mensagem recebida:", data)
        setMessages((prev) => [...prev, data.message])
        scrollToBottom()
      })

      socketService.onUserJoined((data) => {
        console.log("[v0] Usuário entrou:", data)
        if (data.userId !== user?._id) {
          setOtherUserOnline(true)
        }
      })

      socketService.onUserLeft((data) => {
        console.log("[v0] Usuário saiu:", data)
        if (data.userId !== user?._id) {
          setOtherUserOnline(false)
        }
      })

      // Carrega histórico de mensagens
      loadMessages()

      return () => {
        socketService.leaveChatRoom(appointmentId)
        socketService.offAllListeners()
      }
    }
  }, [appointmentId, token, user?._id])

  const loadMessages = async () => {
    try {
      setLoading(true)
      const response = await chatApi.getMessages(appointmentId)
      setMessages(response.data?.messages || [])
      scrollToBottom()
    } catch (error) {
      console.error("Erro ao carregar mensagens:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar as mensagens",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const scrollToBottom = () => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
    }, 100)
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newMessage.trim() || sending) return

    try {
      setSending(true)

      // Envia via Socket.IO para tempo real
      socketService.sendMessage(appointmentId, newMessage.trim())

      // Salva no banco via API
      await chatApi.sendMessage(appointmentId, newMessage.trim())

      setNewMessage("")
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error)
      toast({
        title: "Erro",
        description: "Não foi possível enviar a mensagem",
        variant: "destructive",
      })
    } finally {
      setSending(false)
    }
  }

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp)
    const today = new Date()
    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)

    if (date.toDateString() === today.toDateString()) {
      return "Hoje"
    } else if (date.toDateString() === yesterday.toDateString()) {
      return "Ontem"
    } else {
      return date.toLocaleDateString("pt-BR")
    }
  }

  const groupMessagesByDate = (messages: Message[]) => {
    const groups: { [key: string]: Message[] } = {}

    messages.forEach((message) => {
      const dateKey = new Date(message.timestamp).toDateString()
      if (!groups[dateKey]) {
        groups[dateKey] = []
      }
      groups[dateKey].push(message)
    })

    return groups
  }

  const messageGroups = groupMessagesByDate(messages)

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader className="flex-shrink-0 border-b">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <User className="h-5 w-5" />
            <span>{otherUser.name}</span>
          </CardTitle>
          <div className="flex items-center space-x-2 text-sm">
            <div className={`w-2 h-2 rounded-full ${isConnected ? "bg-green-500" : "bg-red-500"}`} />
            <span className="text-muted-foreground">
              {isConnected ? (otherUserOnline ? "Online" : "Offline") : "Desconectado"}
            </span>
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        {/* Área de mensagens */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-sm text-muted-foreground">Carregando mensagens...</p>
            </div>
          ) : Object.keys(messageGroups).length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Nenhuma mensagem ainda</p>
              <p className="text-sm text-muted-foreground mt-1">Inicie a conversa!</p>
            </div>
          ) : (
            Object.entries(messageGroups).map(([dateKey, dayMessages]) => (
              <div key={dateKey}>
                {/* Separador de data */}
                <div className="flex items-center justify-center my-4">
                  <div className="bg-muted px-3 py-1 rounded-full text-xs text-muted-foreground">
                    {formatDate(dayMessages[0].timestamp)}
                  </div>
                </div>

                {/* Mensagens do dia */}
                {dayMessages.map((message) => {
                  const isOwnMessage = message.sender._id === user?._id
                  return (
                    <div key={message._id} className={`flex ${isOwnMessage ? "justify-end" : "justify-start"} mb-3`}>
                      <div
                        className={`max-w-[70%] rounded-lg px-3 py-2 ${
                          isOwnMessage ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                        }`}
                      >
                        <p className="text-sm">{message.message}</p>
                        <div className="flex items-center justify-end mt-1 space-x-1">
                          <Clock className="h-3 w-3 opacity-70" />
                          <span className="text-xs opacity-70">{formatTime(message.timestamp)}</span>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Área de envio */}
        <div className="border-t p-4">
          <form onSubmit={handleSendMessage} className="flex space-x-2">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Digite sua mensagem..."
              disabled={!isConnected || sending}
              className="flex-1"
            />
            <Button type="submit" disabled={!isConnected || sending || !newMessage.trim()} size="sm">
              <Send className="h-4 w-4" />
            </Button>
          </form>
          {!isConnected && <p className="text-xs text-red-500 mt-1">Conectando ao chat...</p>}
        </div>
      </CardContent>
    </Card>
  )
}
