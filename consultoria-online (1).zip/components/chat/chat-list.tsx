/**
 * Componente de lista de chats ativos
 * Mostra conversas em andamento para navegação rápida
 */
"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { appointmentsApi } from "@/lib/api"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/hooks/use-toast"
import { MessageCircle, Clock, User } from "lucide-react"
import Link from "next/link"

interface ChatListProps {
  userType: "consultant" | "client"
}

export function ChatList({ userType }: ChatListProps) {
  const { user } = useAuth()
  const [appointments, setAppointments] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadActiveChats()
  }, [])

  const loadActiveChats = async () => {
    try {
      setLoading(true)
      // Busca agendamentos confirmados ou em andamento que podem ter chat
      const response = await appointmentsApi.getAll({
        status: "confirmed,in-progress,scheduled",
        limit: 20,
      })
      setAppointments(response.data?.appointments || [])
    } catch (error) {
      console.error("Erro ao carregar chats:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar os chats",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const today = new Date()
    const diffTime = Math.abs(today.getTime() - date.getTime())
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))

    if (diffDays === 1) return "Hoje"
    if (diffDays === 2) return "Ontem"
    if (diffDays <= 7) return `${diffDays} dias atrás`
    return date.toLocaleDateString("pt-BR")
  }

  const getOtherUser = (appointment: any) => {
    return userType === "consultant" ? appointment.client : appointment.consultant
  }

  const getChatUrl = (appointmentId: string) => {
    return `/dashboard/${userType}/chat/${appointmentId}`
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto"></div>
            <p className="mt-2 text-sm text-muted-foreground">Carregando chats...</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <MessageCircle className="h-5 w-5" />
          <span>Chats Ativos</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {appointments.length === 0 ? (
          <div className="text-center py-6">
            <MessageCircle className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">Nenhum chat ativo</p>
            <p className="text-sm text-muted-foreground mt-1">
              Os chats aparecerão quando você tiver consultas agendadas
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {appointments.map((appointment: any) => {
              const otherUser = getOtherUser(appointment)
              return (
                <Link
                  key={appointment._id}
                  href={getChatUrl(appointment._id)}
                  className="block p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                        <User className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-sm">{otherUser.name}</p>
                        <p className="text-xs text-muted-foreground">{appointment.title}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        <span>{formatDate(appointment.date)}</span>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">{appointment.time}</div>
                    </div>
                  </div>
                </Link>
              )
            })}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
