# Guia de Deploy - Plataforma de Consultoria Online

Este guia explica como fazer o deploy da plataforma de consultoria online usando Docker.

## Pré-requisitos

- Docker e Docker Compose instalados
- MongoDB (local ou cloud como MongoDB Atlas)
- Variáveis de ambiente configuradas

## Configuração das Variáveis de Ambiente

### 1. Frontend (.env.local)
\`\`\`bash
NEXT_PUBLIC_API_URL=https://seu-backend.com
NEXT_PUBLIC_APP_URL=https://seu-frontend.com
\`\`\`

### 2. Backend (.env)
\`\`\`bash
NODE_ENV=production
PORT=5000
MONGODB_URI=mongodb://mongo:27017/consultoria
JWT_SECRET=sua_chave_secreta_muito_segura_aqui
CORS_ORIGIN=https://seu-frontend.com
\`\`\`

## Deploy com Docker Compose

### 1. Build e Start dos Containers
\`\`\`bash
# Build das imagens
docker-compose build

# Iniciar todos os serviços
docker-compose up -d

# Verificar status
docker-compose ps
\`\`\`

### 2. Verificar Logs
\`\`\`bash
# Logs do frontend
docker-compose logs frontend

# Logs do backend
docker-compose logs backend

# Logs do MongoDB
docker-compose logs mongo
\`\`\`

### 3. Parar os Serviços
\`\`\`bash
docker-compose down
\`\`\`

## Deploy em Produção

### Vercel (Frontend)
1. Conecte seu repositório ao Vercel
2. Configure as variáveis de ambiente:
   - `NEXT_PUBLIC_API_URL`
   - `NEXT_PUBLIC_APP_URL`
3. Deploy automático a cada push

### Railway/Render (Backend)
1. Conecte seu repositório
2. Configure as variáveis de ambiente
3. Configure o comando de start: `npm start`

### MongoDB Atlas (Banco de Dados)
1. Crie um cluster no MongoDB Atlas
2. Configure as regras de acesso
3. Use a connection string nas variáveis de ambiente

## Estrutura de Arquivos

\`\`\`
consultoria-online/
├── frontend/                 # Next.js App
│   ├── app/                 # App Router
│   ├── components/          # Componentes React
│   ├── lib/                 # Utilitários
│   └── public/              # Assets estáticos
├── backend/                 # Node.js + Express
│   ├── models/              # Modelos MongoDB
│   ├── routes/              # Rotas da API
│   ├── middleware/          # Middlewares
│   └── server.js            # Servidor principal
├── docker-compose.yml       # Configuração Docker
└── README.md               # Documentação
\`\`\`

## Funcionalidades Implementadas

### ✅ Autenticação
- Registro e login de consultores e clientes
- JWT tokens para sessões
- Proteção de rotas

### ✅ Dashboards
- Dashboard do consultor com métricas
- Dashboard do cliente com histórico
- Gerenciamento de agendamentos

### ✅ Sistema de Agendamento
- Busca de consultores
- Agendamento de consultas
- Controle de status

### ✅ Chat em Tempo Real
- Socket.IO para comunicação
- Histórico de mensagens
- Notificações de status

### ✅ Responsividade
- Design mobile-first
- Tailwind CSS
- Componentes acessíveis

## Monitoramento

### Logs de Aplicação
\`\`\`bash
# Ver logs em tempo real
docker-compose logs -f backend
docker-compose logs -f frontend
\`\`\`

### Health Checks
- Frontend: `http://localhost:3000`
- Backend: `http://localhost:5000/api/health`
- MongoDB: `mongodb://localhost:27017`

## Troubleshooting

### Problemas Comuns

1. **Erro de conexão com MongoDB**
   - Verifique se o MongoDB está rodando
   - Confirme a string de conexão

2. **CORS Error**
   - Verifique a variável `CORS_ORIGIN`
   - Confirme se as URLs estão corretas

3. **Socket.IO não conecta**
   - Verifique se as portas estão abertas
   - Confirme a configuração do CORS no Socket.IO

### Comandos Úteis

\`\`\`bash
# Rebuild containers
docker-compose build --no-cache

# Reset do banco de dados
docker-compose down -v
docker-compose up -d

# Backup do banco
docker exec mongo mongodump --out /backup

# Restore do banco
docker exec mongo mongorestore /backup
\`\`\`

## Segurança

### Checklist de Segurança
- [ ] JWT secrets seguros
- [ ] HTTPS em produção
- [ ] Rate limiting configurado
- [ ] Validação de inputs
- [ ] Sanitização de dados
- [ ] CORS configurado corretamente

### Variáveis Sensíveis
Nunca commite:
- JWT_SECRET
- MONGODB_URI com credenciais
- Chaves de API
- Senhas de email

## Suporte

Para problemas ou dúvidas:
1. Verifique os logs dos containers
2. Consulte a documentação das APIs
3. Teste as rotas individualmente
4. Verifique as variáveis de ambiente
