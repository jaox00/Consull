/**
 * Modelo de usuário para consultores e clientes
 * Inclui autenticação, perfil e configurações específicas por tipo
 */

const mongoose = require("mongoose")
const bcrypt = require("bcryptjs")

const userSchema = new mongoose.Schema(
  {
    // Informações básicas
    name: {
      type: String,
      required: [true, "Nome é obrigatório"],
      trim: true,
      maxlength: [100, "Nome deve ter no máximo 100 caracteres"],
    },
    email: {
      type: String,
      required: [true, "Email é obrigatório"],
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, "Email inválido"],
    },
    password: {
      type: String,
      required: [true, "Senha é obrigatória"],
      minlength: [6, "Senha deve ter no mínimo 6 caracteres"],
      select: false, // Não retorna a senha por padrão nas consultas
    },

    // Tipo de usuário
    userType: {
      type: String,
      enum: ["client", "consultant"],
      required: [true, "Tipo de usuário é obrigatório"],
    },

    // Informações do perfil
    phone: {
      type: String,
      trim: true,
    },
    avatar: {
      type: String, // URL da imagem
      default: null,
    },
    bio: {
      type: String,
      maxlength: [500, "Bio deve ter no máximo 500 caracteres"],
    },

    // Configurações específicas para consultores
    consultantInfo: {
      specialties: [
        {
          type: String,
          trim: true,
        },
      ],
      experience: {
        type: Number, // Anos de experiência
        min: 0,
      },
      hourlyRate: {
        type: Number,
        min: 0,
      },
      availability: {
        monday: { start: String, end: String, available: { type: Boolean, default: true } },
        tuesday: { start: String, end: String, available: { type: Boolean, default: true } },
        wednesday: { start: String, end: String, available: { type: Boolean, default: true } },
        thursday: { start: String, end: String, available: { type: Boolean, default: true } },
        friday: { start: String, end: String, available: { type: Boolean, default: true } },
        saturday: { start: String, end: String, available: { type: Boolean, default: false } },
        sunday: { start: String, end: String, available: { type: Boolean, default: false } },
      },
      rating: {
        average: { type: Number, default: 0, min: 0, max: 5 },
        count: { type: Number, default: 0 },
      },
    },

    // Status da conta
    isActive: {
      type: Boolean,
      default: true,
    },
    isVerified: {
      type: Boolean,
      default: false,
    },
    lastLogin: {
      type: Date,
    },
  },
  {
    timestamps: true, // Adiciona createdAt e updatedAt automaticamente
  },
)

// Middleware para hash da senha antes de salvar
userSchema.pre("save", async function (next) {
  // Só faz hash se a senha foi modificada
  if (!this.isModified("password")) return next()

  try {
    // Hash da senha com salt de 12 rounds
    const salt = await bcrypt.genSalt(12)
    this.password = await bcrypt.hash(this.password, salt)
    next()
  } catch (error) {
    next(error)
  }
})

// Método para comparar senhas
userSchema.methods.comparePassword = async function (candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password)
}

// Método para obter dados públicos do usuário (sem senha)
userSchema.methods.toPublicJSON = function () {
  const user = this.toObject()
  delete user.password
  return user
}

// Índices para melhor performance
userSchema.index({ email: 1 })
userSchema.index({ userType: 1 })
userSchema.index({ "consultantInfo.specialties": 1 })

module.exports = mongoose.model("User", userSchema)
