/**
 * Modelo de mensagens do chat
 * Armazena histórico de conversas entre consultores e clientes
 */

const mongoose = require("mongoose")

const messageSchema = new mongoose.Schema(
  {
    // Sala de chat (relacionada ao agendamento)
    chatRoomId: {
      type: String,
      required: [true, "ID da sala de chat é obrigatório"],
      index: true,
    },

    // Remetente
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: [true, "Remetente é obrigatório"],
    },
    senderType: {
      type: String,
      enum: ["client", "consultant"],
      required: [true, "Tipo do remetente é obrigatório"],
    },

    // Conteúdo da mensagem
    content: {
      type: String,
      required: [true, "Conteúdo da mensagem é obrigatório"],
      trim: true,
      maxlength: [2000, "Mensagem deve ter no máximo 2000 caracteres"],
    },

    // Tipo de mensagem
    messageType: {
      type: String,
      enum: ["text", "file", "image", "system"],
      default: "text",
    },

    // Informações de arquivo (se aplicável)
    fileInfo: {
      originalName: String,
      fileName: String,
      fileSize: Number,
      mimeType: String,
      fileUrl: String,
    },

    // Status da mensagem
    isRead: {
      type: Boolean,
      default: false,
    },
    readAt: {
      type: Date,
    },

    // Mensagem editada
    isEdited: {
      type: Boolean,
      default: false,
    },
    editedAt: {
      type: Date,
    },
  },
  {
    timestamps: true,
  },
)

// Índices para melhor performance
messageSchema.index({ chatRoomId: 1, createdAt: -1 })
messageSchema.index({ sender: 1 })

module.exports = mongoose.model("Message", messageSchema)
