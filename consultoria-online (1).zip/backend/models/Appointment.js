/**
 * Modelo de agendamento de consultas
 * Gerencia consultas entre consultores e clientes
 */

const mongoose = require("mongoose")

const appointmentSchema = new mongoose.Schema(
  {
    // Participantes
    client: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: [true, "Cliente é obrigatório"],
    },
    consultant: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: [true, "Consultor é obrigatório"],
    },

    // Informações da consulta
    title: {
      type: String,
      required: [true, "Título é obrigatório"],
      trim: true,
      maxlength: [200, "Título deve ter no máximo 200 caracteres"],
    },
    description: {
      type: String,
      trim: true,
      maxlength: [1000, "Descrição deve ter no máximo 1000 caracteres"],
    },

    // Data e horário
    scheduledDate: {
      type: Date,
      required: [true, "Data agendada é obrigatória"],
    },
    duration: {
      type: Number, // Duração em minutos
      required: [true, "Duração é obrigatória"],
      min: [15, "Duração mínima é 15 minutos"],
      max: [480, "Duração máxima é 8 horas"],
      default: 60,
    },

    // Status da consulta
    status: {
      type: String,
      enum: ["scheduled", "confirmed", "in-progress", "completed", "cancelled", "no-show"],
      default: "scheduled",
    },

    // Informações financeiras
    price: {
      type: Number,
      required: [true, "Preço é obrigatório"],
      min: 0,
    },
    paymentStatus: {
      type: String,
      enum: ["pending", "paid", "refunded"],
      default: "pending",
    },

    // Notas e feedback
    consultantNotes: {
      type: String,
      maxlength: [2000, "Notas do consultor devem ter no máximo 2000 caracteres"],
    },
    clientFeedback: {
      rating: {
        type: Number,
        min: 1,
        max: 5,
      },
      comment: {
        type: String,
        maxlength: [1000, "Comentário deve ter no máximo 1000 caracteres"],
      },
    },

    // Informações de cancelamento
    cancellationReason: {
      type: String,
      maxlength: [500, "Motivo do cancelamento deve ter no máximo 500 caracteres"],
    },
    cancelledBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    cancelledAt: {
      type: Date,
    },

    // Link da sala de chat
    chatRoomId: {
      type: String,
      unique: true,
    },
  },
  {
    timestamps: true,
  },
)

// Middleware para gerar ID da sala de chat
appointmentSchema.pre("save", function (next) {
  if (!this.chatRoomId) {
    this.chatRoomId = `appointment_${this._id}_${Date.now()}`
  }
  next()
})

// Índices para melhor performance
appointmentSchema.index({ client: 1, scheduledDate: -1 })
appointmentSchema.index({ consultant: 1, scheduledDate: -1 })
appointmentSchema.index({ status: 1 })
appointmentSchema.index({ scheduledDate: 1 })

module.exports = mongoose.model("Appointment", appointmentSchema)
