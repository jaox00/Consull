/**
 * Servidor principal do backend da plataforma de consultoria
 * Configuração do Express, Socket.IO, MongoDB e middlewares de segurança
 */

const express = require("express")
const http = require("http")
const socketIo = require("socket.io")
const mongoose = require("mongoose")
const cors = require("cors")
const helmet = require("helmet")
const rateLimit = require("express-rate-limit")
require("dotenv").config()

const app = express()
const server = http.createServer(app)

// Configuração do Socket.IO para chat em tempo real
const io = socketIo(server, {
  cors: {
    origin: process.env.CORS_ORIGIN || "http://localhost:3000",
    methods: ["GET", "POST"],
  },
})

// Middlewares de segurança
app.use(helmet())

// Rate limiting - limita requisições por IP
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 100, // máximo 100 requests por IP por janela de tempo
})
app.use(limiter)

// CORS
app.use(
  cors({
    origin: process.env.CORS_ORIGIN || "http://localhost:3000",
    credentials: true,
  }),
)

// Parser JSON
app.use(express.json({ limit: "10mb" }))
app.use(express.urlencoded({ extended: true }))

// Conexão com MongoDB
mongoose
  .connect(process.env.MONGODB_URI || "mongodb://localhost:27017/consultoria", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("✅ Conectado ao MongoDB"))
  .catch((err) => console.error("❌ Erro ao conectar ao MongoDB:", err))

// Rotas da API
app.use("/api/auth", require("./routes/auth"))
app.use("/api/users", require("./routes/users"))
app.use("/api/appointments", require("./routes/appointments"))
app.use("/api/chat", require("./routes/chat"))

// Rota de teste
app.get("/api/health", (req, res) => {
  res.json({
    message: "Backend da Consultoria Online funcionando!",
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || "development",
  })
})

// Gerenciamento de conexões Socket.IO para chat em tempo real
const activeUsers = new Map()

io.on("connection", (socket) => {
  console.log(`👤 Usuário conectado: ${socket.id}`)

  // Autenticação via token JWT
  socket.on("authenticate", (data) => {
    const { token } = data
    // Aqui você pode validar o token JWT se necessário
    console.log(`🔐 Usuário autenticado: ${socket.id}`)
  })

  // Usuário entra em uma sala de chat (baseada no appointmentId)
  socket.on("join_chat", (data) => {
    const { appointmentId } = data
    socket.join(appointmentId)

    // Armazena informações do usuário ativo
    activeUsers.set(socket.id, { appointmentId })

    console.log(`👥 Usuário ${socket.id} entrou no chat ${appointmentId}`)

    // Notifica outros usuários na sala
    socket.to(appointmentId).emit("user_joined", {
      userId: socket.id,
      message: "Usuário entrou na conversa",
    })
  })

  // Usuário sai de uma sala de chat
  socket.on("leave_chat", (data) => {
    const { appointmentId } = data
    socket.leave(appointmentId)
    console.log(`👋 Usuário ${socket.id} saiu do chat ${appointmentId}`)
  })

  // Recebe e retransmite mensagens
  socket.on("send_message", (data) => {
    const { appointmentId, message, timestamp } = data

    // Cria objeto da mensagem para retransmitir
    const messageData = {
      message: {
        _id: new Date().getTime().toString(), // ID temporário
        sender: {
          _id: socket.userId || socket.id,
          name: socket.userName || "Usuário",
          userType: socket.userType || "client",
        },
        message,
        timestamp: timestamp || new Date().toISOString(),
        read: false,
      },
    }

    // Retransmite a mensagem para todos na sala
    io.to(appointmentId).emit("new_message", messageData)

    console.log(`💬 Mensagem enviada no chat ${appointmentId}`)
  })

  // Usuário está digitando
  socket.on("typing", (data) => {
    const { appointmentId, isTyping } = data
    socket.to(appointmentId).emit("user_typing", { userId: socket.id, isTyping })
  })

  // Desconexão
  socket.on("disconnect", () => {
    const userInfo = activeUsers.get(socket.id)
    if (userInfo) {
      const { appointmentId } = userInfo
      socket.to(appointmentId).emit("user_left", {
        userId: socket.id,
        message: "Usuário saiu da conversa",
      })
      activeUsers.delete(socket.id)
    }
    console.log(`👋 Usuário desconectado: ${socket.id}`)
  })
})

// Middleware de tratamento de erros
app.use((err, req, res, next) => {
  console.error("❌ Erro no servidor:", err.stack)
  res.status(500).json({
    message: "Erro interno do servidor",
    error: process.env.NODE_ENV === "development" ? err.message : "Algo deu errado",
  })
})

// Middleware para rotas não encontradas
app.use("*", (req, res) => {
  res.status(404).json({ message: "Rota não encontrada" })
})

const PORT = process.env.PORT || 5000

server.listen(PORT, () => {
  console.log(`🚀 Servidor rodando na porta ${PORT}`)
  console.log(`🌐 Ambiente: ${process.env.NODE_ENV || "development"}`)
  console.log(`📊 MongoDB: ${process.env.MONGODB_URI || "mongodb://localhost:27017/consultoria"}`)
})

module.exports = { app, server, io }
