/**
 * Middleware de autenticação JWT
 * Verifica tokens e protege rotas
 */

const jwt = require("jsonwebtoken")
const User = require("../models/User")

// Middleware para verificar token JWT
const authenticateToken = async (req, res, next) => {
  try {
    // Busca o token no header Authorization
    const authHeader = req.headers.authorization
    const token = authHeader && authHeader.split(" ")[1] // Bearer TOKEN

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Token de acesso requerido",
      })
    }

    // Verifica e decodifica o token
    const decoded = jwt.verify(token, process.env.JWT_SECRET)

    // Busca o usuário no banco de dados
    const user = await User.findById(decoded.userId).select("-password")

    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Token inválido - usuário não encontrado",
      })
    }

    if (!user.isActive) {
      return res.status(401).json({
        success: false,
        message: "Conta desativada",
      })
    }

    // Adiciona o usuário ao objeto request
    req.user = user
    next()
  } catch (error) {
    console.error("Erro na autenticação:", error)

    if (error.name === "JsonWebTokenError") {
      return res.status(401).json({
        success: false,
        message: "Token inválido",
      })
    }

    if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        success: false,
        message: "Token expirado",
      })
    }

    res.status(500).json({
      success: false,
      message: "Erro interno do servidor",
    })
  }
}

// Middleware para verificar tipo de usuário
const requireUserType = (userType) => {
  return (req, res, next) => {
    if (req.user.userType !== userType) {
      return res.status(403).json({
        success: false,
        message: `Acesso restrito a ${userType === "consultant" ? "consultores" : "clientes"}`,
      })
    }
    next()
  }
}

// Middleware para verificar se é consultor OU cliente (para rotas compartilhadas)
const requireConsultantOrClient = (req, res, next) => {
  if (!["consultant", "client"].includes(req.user.userType)) {
    return res.status(403).json({
      success: false,
      message: "Acesso não autorizado",
    })
  }
  next()
}

module.exports = {
  authenticateToken,
  requireUserType,
  requireConsultantOrClient,
}
