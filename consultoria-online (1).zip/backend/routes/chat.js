/**
 * Rotas para gerenciamento do chat
 * Histórico de mensagens e informações das salas
 */

const express = require("express")
const { body, validationResult } = require("express-validator")
const Message = require("../models/Message")
const Appointment = require("../models/Appointment")
const { authenticateToken } = require("../middleware/auth")

const router = express.Router()

// GET /api/chat/:roomId/messages - Obter histórico de mensagens
router.get("/:roomId/messages", authenticateToken, async (req, res) => {
  try {
    const { roomId } = req.params
    const { page = 1, limit = 50 } = req.query

    // Verifica se o usuário tem acesso a esta sala
    const appointment = await Appointment.findOne({ chatRoomId: roomId })

    if (!appointment) {
      return res.status(404).json({
        success: false,
        message: "Sala de chat não encontrada",
      })
    }

    const hasAccess =
      appointment.client.toString() === req.user._id.toString() ||
      appointment.consultant.toString() === req.user._id.toString()

    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: "Acesso negado",
      })
    }

    // Paginação (mensagens mais recentes primeiro)
    const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

    const messages = await Message.find({ chatRoomId: roomId })
      .populate("sender", "name avatar")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await Message.countDocuments({ chatRoomId: roomId })

    // Marca mensagens como lidas
    await Message.updateMany(
      {
        chatRoomId: roomId,
        sender: { $ne: req.user._id },
        isRead: false,
      },
      {
        isRead: true,
        readAt: new Date(),
      },
    )

    res.json({
      success: true,
      data: {
        messages: messages.reverse(), // Retorna em ordem cronológica
        pagination: {
          current: Number.parseInt(page),
          pages: Math.ceil(total / Number.parseInt(limit)),
          total,
        },
      },
    })
  } catch (error) {
    console.error("Erro ao obter mensagens:", error)
    res.status(500).json({
      success: false,
      message: "Erro interno do servidor",
    })
  }
})

// POST /api/chat/:roomId/messages - Salvar mensagem no histórico
router.post(
  "/:roomId/messages",
  authenticateToken,
  [body("content").trim().isLength({ min: 1, max: 2000 }).withMessage("Mensagem deve ter entre 1 e 2000 caracteres")],
  async (req, res) => {
    try {
      // Verifica erros de validação
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          message: "Dados inválidos",
          errors: errors.array(),
        })
      }

      const { roomId } = req.params
      const { content, messageType = "text", fileInfo } = req.body

      // Verifica se o usuário tem acesso a esta sala
      const appointment = await Appointment.findOne({ chatRoomId: roomId })

      if (!appointment) {
        return res.status(404).json({
          success: false,
          message: "Sala de chat não encontrada",
        })
      }

      const hasAccess =
        appointment.client.toString() === req.user._id.toString() ||
        appointment.consultant.toString() === req.user._id.toString()

      if (!hasAccess) {
        return res.status(403).json({
          success: false,
          message: "Acesso negado",
        })
      }

      // Cria a mensagem
      const message = new Message({
        chatRoomId: roomId,
        sender: req.user._id,
        senderType: req.user.userType,
        content,
        messageType,
        fileInfo,
      })

      await message.save()
      await message.populate("sender", "name avatar")

      res.status(201).json({
        success: true,
        message: "Mensagem salva com sucesso",
        data: {
          message,
        },
      })
    } catch (error) {
      console.error("Erro ao salvar mensagem:", error)
      res.status(500).json({
        success: false,
        message: "Erro interno do servidor",
      })
    }
  },
)

// GET /api/chat/rooms - Listar salas de chat do usuário
router.get("/rooms", authenticateToken, async (req, res) => {
  try {
    // Busca agendamentos do usuário que têm sala de chat
    const filters = {}
    if (req.user.userType === "client") {
      filters.client = req.user._id
    } else if (req.user.userType === "consultant") {
      filters.consultant = req.user._id
    }

    const appointments = await Appointment.find({
      ...filters,
      chatRoomId: { $exists: true },
    })
      .populate([
        { path: "client", select: "name avatar" },
        { path: "consultant", select: "name avatar" },
      ])
      .sort({ updatedAt: -1 })

    // Para cada sala, busca a última mensagem e contagem de não lidas
    const rooms = await Promise.all(
      appointments.map(async (appointment) => {
        const lastMessage = await Message.findOne({ chatRoomId: appointment.chatRoomId })
          .sort({ createdAt: -1 })
          .populate("sender", "name")

        const unreadCount = await Message.countDocuments({
          chatRoomId: appointment.chatRoomId,
          sender: { $ne: req.user._id },
          isRead: false,
        })

        return {
          roomId: appointment.chatRoomId,
          appointment: {
            _id: appointment._id,
            title: appointment.title,
            scheduledDate: appointment.scheduledDate,
            status: appointment.status,
            client: appointment.client,
            consultant: appointment.consultant,
          },
          lastMessage,
          unreadCount,
          updatedAt: appointment.updatedAt,
        }
      }),
    )

    res.json({
      success: true,
      data: {
        rooms,
      },
    })
  } catch (error) {
    console.error("Erro ao listar salas:", error)
    res.status(500).json({
      success: false,
      message: "Erro interno do servidor",
    })
  }
})

module.exports = router
