/**
 * Rotas para gerenciamento de usuários
 * Perfil, configurações e listagem de consultores
 */

const express = require("express")
const { body, validationResult } = require("express-validator")
const User = require("../models/User")
const { authenticateToken, requireUserType } = require("../middleware/auth")

const router = express.Router()

// GET /api/users/consultants - Listar consultores disponíveis
router.get("/consultants", async (req, res) => {
  try {
    const { specialty, minRating, maxRate, page = 1, limit = 10 } = req.query

    // Filtros de busca
    const filters = {
      userType: "consultant",
      isActive: true,
    }

    if (specialty) {
      filters["consultantInfo.specialties"] = { $in: [new RegExp(specialty, "i")] }
    }

    if (minRating) {
      filters["consultantInfo.rating.average"] = { $gte: Number.parseFloat(minRating) }
    }

    if (maxRate) {
      filters["consultantInfo.hourlyRate"] = { $lte: Number.parseFloat(maxRate) }
    }

    // Paginação
    const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

    const consultants = await User.find(filters)
      .select("-password")
      .sort({ "consultantInfo.rating.average": -1, createdAt: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await User.countDocuments(filters)

    res.json({
      success: true,
      data: {
        consultants,
        pagination: {
          current: Number.parseInt(page),
          pages: Math.ceil(total / Number.parseInt(limit)),
          total,
        },
      },
    })
  } catch (error) {
    console.error("Erro ao listar consultores:", error)
    res.status(500).json({
      success: false,
      message: "Erro interno do servidor",
    })
  }
})

// GET /api/users/profile - Obter perfil do usuário logado
router.get("/profile", authenticateToken, async (req, res) => {
  try {
    res.json({
      success: true,
      data: {
        user: req.user.toPublicJSON(),
      },
    })
  } catch (error) {
    console.error("Erro ao obter perfil:", error)
    res.status(500).json({
      success: false,
      message: "Erro interno do servidor",
    })
  }
})

// PUT /api/users/profile - Atualizar perfil do usuário
router.put(
  "/profile",
  authenticateToken,
  [
    body("name").optional().trim().isLength({ min: 2, max: 100 }).withMessage("Nome deve ter entre 2 e 100 caracteres"),
    body("phone").optional().isMobilePhone("pt-BR").withMessage("Telefone inválido"),
    body("bio").optional().isLength({ max: 500 }).withMessage("Bio deve ter no máximo 500 caracteres"),
  ],
  async (req, res) => {
    try {
      // Verifica erros de validação
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          message: "Dados inválidos",
          errors: errors.array(),
        })
      }

      const { name, phone, bio, avatar } = req.body

      // Campos permitidos para atualização
      const updateData = {}
      if (name) updateData.name = name
      if (phone) updateData.phone = phone
      if (bio) updateData.bio = bio
      if (avatar) updateData.avatar = avatar

      // Atualiza informações específicas do consultor
      if (req.user.userType === "consultant") {
        const { specialties, experience, hourlyRate, availability } = req.body

        if (specialties) updateData["consultantInfo.specialties"] = specialties
        if (experience !== undefined) updateData["consultantInfo.experience"] = experience
        if (hourlyRate !== undefined) updateData["consultantInfo.hourlyRate"] = hourlyRate
        if (availability) updateData["consultantInfo.availability"] = availability
      }

      const updatedUser = await User.findByIdAndUpdate(req.user._id, updateData, {
        new: true,
        runValidators: true,
      }).select("-password")

      res.json({
        success: true,
        message: "Perfil atualizado com sucesso",
        data: {
          user: updatedUser.toPublicJSON(),
        },
      })
    } catch (error) {
      console.error("Erro ao atualizar perfil:", error)
      res.status(500).json({
        success: false,
        message: "Erro interno do servidor",
      })
    }
  },
)

// GET /api/users/:id - Obter perfil público de um usuário
router.get("/:id", async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select("-password")

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "Usuário não encontrado",
      })
    }

    if (!user.isActive) {
      return res.status(404).json({
        success: false,
        message: "Usuário não encontrado",
      })
    }

    res.json({
      success: true,
      data: {
        user: user.toPublicJSON(),
      },
    })
  } catch (error) {
    console.error("Erro ao obter usuário:", error)
    res.status(500).json({
      success: false,
      message: "Erro interno do servidor",
    })
  }
})

// PUT /api/users/change-password - Alterar senha
router.put(
  "/change-password",
  authenticateToken,
  [
    body("currentPassword").notEmpty().withMessage("Senha atual é obrigatória"),
    body("newPassword").isLength({ min: 6 }).withMessage("Nova senha deve ter no mínimo 6 caracteres"),
  ],
  async (req, res) => {
    try {
      // Verifica erros de validação
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          message: "Dados inválidos",
          errors: errors.array(),
        })
      }

      const { currentPassword, newPassword } = req.body

      // Busca o usuário com a senha
      const user = await User.findById(req.user._id).select("+password")

      // Verifica a senha atual
      const isCurrentPasswordValid = await user.comparePassword(currentPassword)

      if (!isCurrentPasswordValid) {
        return res.status(400).json({
          success: false,
          message: "Senha atual incorreta",
        })
      }

      // Atualiza a senha
      user.password = newPassword
      await user.save()

      res.json({
        success: true,
        message: "Senha alterada com sucesso",
      })
    } catch (error) {
      console.error("Erro ao alterar senha:", error)
      res.status(500).json({
        success: false,
        message: "Erro interno do servidor",
      })
    }
  },
)

module.exports = router
