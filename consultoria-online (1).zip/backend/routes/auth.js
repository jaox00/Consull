/**
 * Rotas de autenticação
 * Cadastro, login, logout e gerenciamento de tokens
 */

const express = require("express")
const jwt = require("jsonwebtoken")
const { body, validationResult } = require("express-validator")
const User = require("../models/User")
const { authenticateToken } = require("../middleware/auth")

const router = express.Router()

// Função para gerar token JWT
const generateToken = (userId) => {
  return jwt.sign({ userId }, process.env.JWT_SECRET, {
    expiresIn: "7d", // Token válido por 7 dias
  })
}

// POST /api/auth/register - Cadastro de usuário
router.post(
  "/register",
  [
    body("name").trim().isLength({ min: 2, max: 100 }).withMessage("Nome deve ter entre 2 e 100 caracteres"),
    body("email").isEmail().normalizeEmail().withMessage("Email inválido"),
    body("password").isLength({ min: 6 }).withMessage("Senha deve ter no mínimo 6 caracteres"),
    body("userType").isIn(["client", "consultant"]).withMessage("Tipo de usuário deve ser 'client' ou 'consultant'"),
    body("phone").optional().isMobilePhone("pt-BR").withMessage("Telefone inválido"),
  ],
  async (req, res) => {
    try {
      // Verifica erros de validação
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          message: "Dados inválidos",
          errors: errors.array(),
        })
      }

      const { name, email, password, userType, phone, bio } = req.body

      // Verifica se o email já existe
      const existingUser = await User.findOne({ email })
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: "Email já cadastrado",
        })
      }

      // Cria novo usuário
      const userData = {
        name,
        email,
        password,
        userType,
        phone,
        bio,
      }

      // Adiciona informações específicas para consultores
      if (userType === "consultant") {
        userData.consultantInfo = {
          specialties: req.body.specialties || [],
          experience: req.body.experience || 0,
          hourlyRate: req.body.hourlyRate || 0,
          availability: {
            monday: { start: "09:00", end: "17:00", available: true },
            tuesday: { start: "09:00", end: "17:00", available: true },
            wednesday: { start: "09:00", end: "17:00", available: true },
            thursday: { start: "09:00", end: "17:00", available: true },
            friday: { start: "09:00", end: "17:00", available: true },
            saturday: { start: "09:00", end: "17:00", available: false },
            sunday: { start: "09:00", end: "17:00", available: false },
          },
        }
      }

      const user = new User(userData)
      await user.save()

      // Gera token JWT
      const token = generateToken(user._id)

      // Atualiza último login
      user.lastLogin = new Date()
      await user.save()

      res.status(201).json({
        success: true,
        message: "Usuário cadastrado com sucesso",
        data: {
          user: user.toPublicJSON(),
          token,
        },
      })
    } catch (error) {
      console.error("Erro no cadastro:", error)
      res.status(500).json({
        success: false,
        message: "Erro interno do servidor",
      })
    }
  },
)

// POST /api/auth/login - Login de usuário
router.post(
  "/login",
  [
    body("email").isEmail().normalizeEmail().withMessage("Email inválido"),
    body("password").notEmpty().withMessage("Senha é obrigatória"),
  ],
  async (req, res) => {
    try {
      // Verifica erros de validação
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          message: "Dados inválidos",
          errors: errors.array(),
        })
      }

      const { email, password } = req.body

      // Busca usuário por email (incluindo senha para comparação)
      const user = await User.findOne({ email }).select("+password")

      if (!user) {
        return res.status(401).json({
          success: false,
          message: "Email ou senha incorretos",
        })
      }

      // Verifica se a conta está ativa
      if (!user.isActive) {
        return res.status(401).json({
          success: false,
          message: "Conta desativada",
        })
      }

      // Compara a senha
      const isPasswordValid = await user.comparePassword(password)

      if (!isPasswordValid) {
        return res.status(401).json({
          success: false,
          message: "Email ou senha incorretos",
        })
      }

      // Gera token JWT
      const token = generateToken(user._id)

      // Atualiza último login
      user.lastLogin = new Date()
      await user.save()

      res.json({
        success: true,
        message: "Login realizado com sucesso",
        data: {
          user: user.toPublicJSON(),
          token,
        },
      })
    } catch (error) {
      console.error("Erro no login:", error)
      res.status(500).json({
        success: false,
        message: "Erro interno do servidor",
      })
    }
  },
)

// GET /api/auth/me - Obter dados do usuário logado
router.get("/me", authenticateToken, async (req, res) => {
  try {
    res.json({
      success: true,
      data: {
        user: req.user.toPublicJSON(),
      },
    })
  } catch (error) {
    console.error("Erro ao obter dados do usuário:", error)
    res.status(500).json({
      success: false,
      message: "Erro interno do servidor",
    })
  }
})

// POST /api/auth/refresh - Renovar token
router.post("/refresh", authenticateToken, async (req, res) => {
  try {
    // Gera novo token
    const token = generateToken(req.user._id)

    res.json({
      success: true,
      message: "Token renovado com sucesso",
      data: {
        token,
      },
    })
  } catch (error) {
    console.error("Erro ao renovar token:", error)
    res.status(500).json({
      success: false,
      message: "Erro interno do servidor",
    })
  }
})

// POST /api/auth/logout - Logout (invalidar token no frontend)
router.post("/logout", authenticateToken, async (req, res) => {
  try {
    // Em uma implementação mais robusta, você poderia manter uma blacklist de tokens
    // Por enquanto, apenas retorna sucesso (o frontend deve remover o token)

    res.json({
      success: true,
      message: "Logout realizado com sucesso",
    })
  } catch (error) {
    console.error("Erro no logout:", error)
    res.status(500).json({
      success: false,
      message: "Erro interno do servidor",
    })
  }
})

module.exports = router
