/**
 * Rotas para gerenciamento de agendamentos
 * Criação, listagem, atualização e cancelamento de consultas
 */

const express = require("express")
const { body, validationResult } = require("express-validator")
const Appointment = require("../models/Appointment")
const User = require("../models/User")
const { authenticateToken, requireUserType } = require("../middleware/auth")

const router = express.Router()

// POST /api/appointments - Criar novo agendamento (apenas clientes)
router.post(
  "/",
  authenticateToken,
  requireUserType("client"),
  [
    body("consultant").isMongoId().withMessage("ID do consultor inválido"),
    body("title").trim().isLength({ min: 5, max: 200 }).withMessage("Título deve ter entre 5 e 200 caracteres"),
    body("description").optional().isLength({ max: 1000 }).withMessage("Descrição deve ter no máximo 1000 caracteres"),
    body("scheduledDate").isISO8601().withMessage("Data inválida"),
    body("duration").isInt({ min: 15, max: 480 }).withMessage("Duração deve ser entre 15 e 480 minutos"),
  ],
  async (req, res) => {
    try {
      // Verifica erros de validação
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          message: "Dados inválidos",
          errors: errors.array(),
        })
      }

      const { consultant, title, description, scheduledDate, duration } = req.body

      // Verifica se o consultor existe e está ativo
      const consultantUser = await User.findById(consultant)
      if (!consultantUser || consultantUser.userType !== "consultant" || !consultantUser.isActive) {
        return res.status(404).json({
          success: false,
          message: "Consultor não encontrado",
        })
      }

      // Verifica se a data não é no passado
      const appointmentDate = new Date(scheduledDate)
      if (appointmentDate <= new Date()) {
        return res.status(400).json({
          success: false,
          message: "Data deve ser no futuro",
        })
      }

      // Verifica conflitos de horário para o consultor
      const endDate = new Date(appointmentDate.getTime() + duration * 60000)
      const conflictingAppointment = await Appointment.findOne({
        consultant,
        status: { $in: ["scheduled", "confirmed", "in-progress"] },
        $or: [
          {
            scheduledDate: { $lte: appointmentDate },
            $expr: {
              $gte: [{ $add: ["$scheduledDate", { $multiply: ["$duration", 60000] }] }, appointmentDate],
            },
          },
          {
            scheduledDate: { $gte: appointmentDate, $lt: endDate },
          },
        ],
      })

      if (conflictingAppointment) {
        return res.status(400).json({
          success: false,
          message: "Horário não disponível",
        })
      }

      // Calcula o preço baseado na taxa horária do consultor
      const hourlyRate = consultantUser.consultantInfo.hourlyRate || 100
      const price = (hourlyRate * duration) / 60

      // Cria o agendamento
      const appointment = new Appointment({
        client: req.user._id,
        consultant,
        title,
        description,
        scheduledDate: appointmentDate,
        duration,
        price,
      })

      await appointment.save()

      // Popula os dados do cliente e consultor
      await appointment.populate([
        { path: "client", select: "name email avatar" },
        { path: "consultant", select: "name email avatar consultantInfo.specialties" },
      ])

      res.status(201).json({
        success: true,
        message: "Agendamento criado com sucesso",
        data: {
          appointment,
        },
      })
    } catch (error) {
      console.error("Erro ao criar agendamento:", error)
      res.status(500).json({
        success: false,
        message: "Erro interno do servidor",
      })
    }
  },
)

// GET /api/appointments - Listar agendamentos do usuário
router.get("/", authenticateToken, async (req, res) => {
  try {
    const { status, page = 1, limit = 10, startDate, endDate } = req.query

    // Filtros baseados no tipo de usuário
    const filters = {}
    if (req.user.userType === "client") {
      filters.client = req.user._id
    } else if (req.user.userType === "consultant") {
      filters.consultant = req.user._id
    }

    // Filtros adicionais
    if (status) {
      filters.status = status
    }

    if (startDate || endDate) {
      filters.scheduledDate = {}
      if (startDate) filters.scheduledDate.$gte = new Date(startDate)
      if (endDate) filters.scheduledDate.$lte = new Date(endDate)
    }

    // Paginação
    const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

    const appointments = await Appointment.find(filters)
      .populate([
        { path: "client", select: "name email avatar" },
        { path: "consultant", select: "name email avatar consultantInfo.specialties" },
      ])
      .sort({ scheduledDate: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await Appointment.countDocuments(filters)

    res.json({
      success: true,
      data: {
        appointments,
        pagination: {
          current: Number.parseInt(page),
          pages: Math.ceil(total / Number.parseInt(limit)),
          total,
        },
      },
    })
  } catch (error) {
    console.error("Erro ao listar agendamentos:", error)
    res.status(500).json({
      success: false,
      message: "Erro interno do servidor",
    })
  }
})

// GET /api/appointments/:id - Obter detalhes de um agendamento
router.get("/:id", authenticateToken, async (req, res) => {
  try {
    const appointment = await Appointment.findById(req.params.id).populate([
      { path: "client", select: "name email avatar phone" },
      { path: "consultant", select: "name email avatar phone consultantInfo" },
    ])

    if (!appointment) {
      return res.status(404).json({
        success: false,
        message: "Agendamento não encontrado",
      })
    }

    // Verifica se o usuário tem acesso a este agendamento
    const hasAccess =
      appointment.client._id.toString() === req.user._id.toString() ||
      appointment.consultant._id.toString() === req.user._id.toString()

    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: "Acesso negado",
      })
    }

    res.json({
      success: true,
      data: {
        appointment,
      },
    })
  } catch (error) {
    console.error("Erro ao obter agendamento:", error)
    res.status(500).json({
      success: false,
      message: "Erro interno do servidor",
    })
  }
})

// PUT /api/appointments/:id/status - Atualizar status do agendamento
router.put("/:id/status", authenticateToken, async (req, res) => {
  try {
    const { status } = req.body
    const validStatuses = ["confirmed", "in-progress", "completed", "cancelled"]

    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Status inválido",
      })
    }

    const appointment = await Appointment.findById(req.params.id)

    if (!appointment) {
      return res.status(404).json({
        success: false,
        message: "Agendamento não encontrado",
      })
    }

    // Verifica se o usuário tem acesso a este agendamento
    const hasAccess =
      appointment.client.toString() === req.user._id.toString() ||
      appointment.consultant.toString() === req.user._id.toString()

    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: "Acesso negado",
      })
    }

    // Regras de negócio para mudança de status
    if (status === "confirmed" && req.user.userType !== "consultant") {
      return res.status(403).json({
        success: false,
        message: "Apenas consultores podem confirmar agendamentos",
      })
    }

    if (status === "cancelled") {
      appointment.cancelledBy = req.user._id
      appointment.cancelledAt = new Date()
      appointment.cancellationReason = req.body.reason || "Não informado"
    }

    appointment.status = status
    await appointment.save()

    res.json({
      success: true,
      message: "Status atualizado com sucesso",
      data: {
        appointment,
      },
    })
  } catch (error) {
    console.error("Erro ao atualizar status:", error)
    res.status(500).json({
      success: false,
      message: "Erro interno do servidor",
    })
  }
})

// POST /api/appointments/:id/feedback - Adicionar feedback (apenas clientes)
router.post(
  "/:id/feedback",
  authenticateToken,
  requireUserType("client"),
  [
    body("rating").isInt({ min: 1, max: 5 }).withMessage("Avaliação deve ser entre 1 e 5"),
    body("comment").optional().isLength({ max: 1000 }).withMessage("Comentário deve ter no máximo 1000 caracteres"),
  ],
  async (req, res) => {
    try {
      // Verifica erros de validação
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          message: "Dados inválidos",
          errors: errors.array(),
        })
      }

      const { rating, comment } = req.body

      const appointment = await Appointment.findById(req.params.id)

      if (!appointment) {
        return res.status(404).json({
          success: false,
          message: "Agendamento não encontrado",
        })
      }

      // Verifica se é o cliente do agendamento
      if (appointment.client.toString() !== req.user._id.toString()) {
        return res.status(403).json({
          success: false,
          message: "Acesso negado",
        })
      }

      // Verifica se o agendamento foi concluído
      if (appointment.status !== "completed") {
        return res.status(400).json({
          success: false,
          message: "Só é possível avaliar agendamentos concluídos",
        })
      }

      // Adiciona o feedback
      appointment.clientFeedback = { rating, comment }
      await appointment.save()

      // Atualiza a avaliação média do consultor
      const consultant = await User.findById(appointment.consultant)
      const consultantAppointments = await Appointment.find({
        consultant: appointment.consultant,
        status: "completed",
        "clientFeedback.rating": { $exists: true },
      })

      const totalRating = consultantAppointments.reduce((sum, app) => sum + app.clientFeedback.rating, 0)
      const averageRating = totalRating / consultantAppointments.length

      consultant.consultantInfo.rating = {
        average: Math.round(averageRating * 10) / 10, // Arredonda para 1 casa decimal
        count: consultantAppointments.length,
      }
      await consultant.save()

      res.json({
        success: true,
        message: "Feedback adicionado com sucesso",
        data: {
          appointment,
        },
      })
    } catch (error) {
      console.error("Erro ao adicionar feedback:", error)
      res.status(500).json({
        success: false,
        message: "Erro interno do servidor",
      })
    }
  },
)

module.exports = router
